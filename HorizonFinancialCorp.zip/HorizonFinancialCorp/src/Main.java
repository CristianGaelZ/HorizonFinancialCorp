import javax.swing.SwingUtilities;
import controlador.ControladorBanco;
import vistas.RetiroInicioFrame;

public class Main {
    public static void main(String[] args) {
        ControladorBanco controlador = new ControladorBanco();

        SwingUtilities.invokeLater(() -> {
            new RetiroInicioFrame(controlador).setVisible(true);
        });
    }
}

package modelos;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Cuenta {
    private String idPersona;
    private String numeroCuenta;
    private double saldo;
    private String clabe;
    private String tipoCuenta;
    private boolean estadoActivo;
    private String nip;
    private String cvv;
    private String fechaVencimiento;
    private String numeroTarjeta;

    private List<String> historialMovimientos;


    public Cuenta(String idPersona, String numeroCuenta, double saldo, String clabe, String tipoCuenta,
                  boolean estadoActivo, String nip, String cvv, String fechaVencimiento, String numeroTarjeta) {
        this.idPersona = idPersona;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.clabe = clabe;
        this.tipoCuenta = tipoCuenta;
        this.estadoActivo = estadoActivo;
        this.nip = nip;
        this.cvv = cvv;
        this.fechaVencimiento = fechaVencimiento;
        this.numeroTarjeta = numeroTarjeta;
        this.historialMovimientos = new ArrayList<>();  // Inicializamos el historial
    }

    // Métodos getter y setter para todos los campos
    public String getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(String idPersona) {
        this.idPersona = idPersona;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getClabe() {
        return clabe;
    }

    public void setClabe(String clabe) {
        this.clabe = clabe;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public boolean isEstadoActivo() {
        return estadoActivo;
    }

    public void setEstadoActivo(boolean estadoActivo) {
        this.estadoActivo = estadoActivo;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    // Método para generar el NIP de forma estática
    public static String generarNip() {
        Random rand = new Random();
        StringBuilder nipBuilder = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            nipBuilder.append(rand.nextInt(10));  // Genera 4 dígitos
        }
        return nipBuilder.toString();
    }

    // Método para generar el CVV de forma estática
    public static String generarCvv() {
        Random rand = new Random();
        StringBuilder cvvBuilder = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            cvvBuilder.append(rand.nextInt(10));  // Genera 3 dígitos
        }
        return cvvBuilder.toString();
    }

    // Método para generar fecha de vencimiento de forma estática
    public static String generarFechaVencimiento() {
        Random rand = new Random();
        int mes = rand.nextInt(12) + 1;
        int anio = rand.nextInt(10) + 2025;
        return String.format("%02d/%d", mes, anio);
    }

    // Método para generar número de tarjeta de forma estática
    public static String generarNumeroTarjeta() {
        Random rand = new Random();
        StringBuilder numeroTarjetaBuilder = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            numeroTarjetaBuilder.append(rand.nextInt(10));
        }
        return numeroTarjetaBuilder.toString();
    }

    // Método para generar CLABE de forma estática
    public static String generarClabe() {
        Random rand = new Random();
        StringBuilder clabeBuilder = new StringBuilder();
        for (int i = 0; i < 18; i++) {
            clabeBuilder.append(rand.nextInt(10));
        }
        return clabeBuilder.toString();
    }

    // Método estático para crear una cuenta basada en el tipo de cuenta
    public static Cuenta crearCuenta(String idPersona, String tipoCuenta) {
        String numeroCuenta = "CU" + new Random().nextInt(100000);
        double saldo = 0.0;
        String clabe = generarClabe();
        String nip = generarNip();
        String cvv = generarCvv();
        String fechaVencimiento = generarFechaVencimiento();
        String numeroTarjeta = generarNumeroTarjeta();

        if (tipoCuenta.equalsIgnoreCase("Ahorro")) {
            saldo = 1000.0;
        } else if (tipoCuenta.equalsIgnoreCase("Crédito")) {
            saldo = 5000.0;
        } else {
            saldo = 0.0;
        }

        // Retorna una nueva cuenta con los valores generados
        return new Cuenta(idPersona, numeroCuenta, saldo, clabe, tipoCuenta, true, nip, cvv, fechaVencimiento, numeroTarjeta);
    }

    // Método para agregar un movimiento al historial
    public void agregarMovimiento(String movimiento) {
        historialMovimientos.add(movimiento);
    }

    // Método para obtener el historial de movimientos
    public List<String> getHistorialMovimientos() {
        return historialMovimientos;
    }
}

package modelos;

public class Deposito {
    private String idDeposito;
    private double monto;
    private String noCuentaDestino;
    private String numeroTarjetaDestino;
    private String fechaHora;


    public Deposito(String idDeposito, double monto, String noCuentaDestino, String numeroTarjetaDestino, String fechaHora) {
        this.idDeposito = idDeposito;
        this.monto = monto;
        this.noCuentaDestino = noCuentaDestino;
        this.numeroTarjetaDestino = numeroTarjetaDestino;
        this.fechaHora = fechaHora;
    }

    public String getIdDeposito() { return idDeposito; }
    public double getMonto() { return monto; }
    public String getNoCuentaDestino() { return noCuentaDestino; }
    public String getNumeroTarjetaDestino() { return numeroTarjetaDestino; }
    public String getFechaHora() { return fechaHora; }
}

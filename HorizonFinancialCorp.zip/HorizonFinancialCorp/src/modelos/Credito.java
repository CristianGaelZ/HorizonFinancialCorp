package modelos;
import java.util.Date;

public class Credito {
    private String idCredito;
    private double monto;
    private String noCuenta;
    private boolean estadoActivo;
    private String usuario;
    private double tasaInteres;
    private int plazoMeses;
    private boolean aprobado;
    private Date fechaAprobacion; // Nuevo campo para la fecha de aprobación

    // Constructor vacío
    public Credito() {
    }


    public Credito(Persona persona, double monto, int plazoMeses) {
        this.usuario = persona.getNombreUsuario();
        this.monto = monto;
        this.plazoMeses = plazoMeses;
        this.tasaInteres = 12.0;
        this.aprobado = false;
    }

    public Credito(String idCredito, double monto, String noCuenta, boolean estadoActivo, String usuario, double tasaInteres, int plazoMeses, boolean aprobado) {
        this.idCredito = idCredito;
        this.monto = monto;
        this.noCuenta = noCuenta;
        this.estadoActivo = estadoActivo;
        this.usuario = usuario;
        this.tasaInteres = tasaInteres;
        this.plazoMeses = plazoMeses;
        this.aprobado = aprobado;
    }

    // Método para aprobar el crédito, asignando la fecha de aprobación
    public void aprobarCredito() {
        this.aprobado = true;
        this.fechaAprobacion = new Date(); // Asigna la fecha actual como fecha de aprobación
    }

    // Setter y getter para el estado aprobado
    public void setAprobado(boolean aprobado) {
        this.aprobado = aprobado;
    }

    // Método para verificar si el crédito está aprobado
    public boolean isAprobado() {
        return aprobado;
    }

    // Método para obtener el usuario asociado al crédito
    public String getUsuario() {
        return usuario;
    }

    // Método para obtener el plazo en meses
    public int getPlazo() {
        return plazoMeses;
    }

    // Método para calcular el total a pagar (monto + intereses)
    public double calcularTotalPagar() {
        return monto + (monto * (tasaInteres / 100) * plazoMeses / 12);
    }

    // Método para obtener el monto del crédito
    public double getMonto() {
        return monto;
    }

    // Método para obtener la fecha de aprobación
    public Date getFechaAprobacion() {
        return fechaAprobacion;
    }

    // Método para representar el crédito como una cadena de texto
    public String toString() {
        return "Usuario: " + usuario + ", Monto: $" + monto + ", Plazo: " + plazoMeses + " meses, " +
                "Aprobado: " + (aprobado ? "Sí" : "No") + ", Total a Pagar: $" + calcularTotalPagar();
    }

    // Getter para tasa de interés
    public double getTasaInteres() {
        return tasaInteres;
    }

    // Métodos Getters y Setters adicionales
    public String getId() {
        return idCredito; // Método para obtener el idCredito
    }

    public void setIdCredito(String idCredito) {
        this.idCredito = idCredito;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getNoCuenta() {
        return noCuenta;
    }

    public void setNoCuenta(String noCuenta) {
        this.noCuenta = noCuenta;
    }

    public boolean getEstadoActivo() {
        return estadoActivo;
    }

    public void setEstadoActivo(boolean estadoActivo) {
        this.estadoActivo = estadoActivo;
    }
}

package modelos;

public class Retiro {
    private String idRetiro;
    private double monto;
    private String noCuentaOrigen;
    private String numeroTarjetaOrigen;
    private String fechaHora;

    public Retiro(String idRetiro, double monto, String noCuentaOrigen, String numeroTarjetaOrigen, String fechaHora) {
        this.idRetiro = idRetiro;
        this.monto = monto;
        this.noCuentaOrigen = noCuentaOrigen;
        this.numeroTarjetaOrigen = numeroTarjetaOrigen;
        this.fechaHora = fechaHora;
    }

    public String getIdRetiro() { return idRetiro; }
    public double getMonto() { return monto; }
    public String getNoCuentaOrigen() { return noCuentaOrigen; }
    public String getNumeroTarjetaOrigen() { return numeroTarjetaOrigen; }
    public String getFechaHora() { return fechaHora; }
}

package modelos;

public class Transferencias {
    private String idTransferencia;
    private double monto;
    private String noCuentaEnvio;
    private String noCuentaDestino;
    private String clabeEnvio;
    private String clabeDestino;
    private String fechaHora;

    // Constructor con parámetros
    public Transferencias(String idTransferencia, double monto, String noCuentaEnvio, String noCuentaDestino, String clabeEnvio, String clabeDestino, String fechaHora) {
        this.idTransferencia = idTransferencia;
        this.monto = monto;
        this.noCuentaEnvio = noCuentaEnvio;
        this.noCuentaDestino = noCuentaDestino;
        this.clabeEnvio = clabeEnvio;
        this.clabeDestino = clabeDestino;
        this.fechaHora = fechaHora;
    }

    // Getters y setters
    public String getIdTransferencia() {
        return idTransferencia;
    }

    public void setIdTransferencia(String idTransferencia) {
        this.idTransferencia = idTransferencia;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getNoCuentaEnvio() {
        return noCuentaEnvio;
    }

    public void setNoCuentaEnvio(String noCuentaEnvio) {
        this.noCuentaEnvio = noCuentaEnvio;
    }

    public String getNoCuentaDestino() {
        return noCuentaDestino;
    }

    public void setNoCuentaDestino(String noCuentaDestino) {
        this.noCuentaDestino = noCuentaDestino;
    }

    public String getClabeEnvio() {
        return clabeEnvio;
    }

    public void setClabeEnvio(String clabeEnvio) {
        this.clabeEnvio = clabeEnvio;
    }

    public String getClabeDestino() {
        return clabeDestino;
    }

    public void setClabeDestino(String clabeDestino) {
        this.clabeDestino = clabeDestino;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }
}

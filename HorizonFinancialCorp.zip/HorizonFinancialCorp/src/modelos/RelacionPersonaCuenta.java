/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author crist
 */
public class RelacionPersonaCuenta {
    private String idRelacion;
    private String idPersona;
    private String clabe;
    private String noCuenta;
    private boolean estadoActivo;


    //Por cada entidad estoy creando dos tipos de constructores, dependiendo del que se necesite
    //puede que quitemos uno dependiendo su utilidad

    public RelacionPersonaCuenta(String idRelacion, String idPersona, String clabe, String noCuenta,  boolean estadoActivo) {
        this.idRelacion = idRelacion;
        this.idPersona = idPersona;
        this.clabe = clabe;
        this.noCuenta = noCuenta;
        this.estadoActivo = estadoActivo;
    }


    public String getIdRelacion() {
        return idRelacion;
    }
    public void setIdRelacion(String idRelacion) {
        this.idRelacion = idRelacion;
    }
    public String getIdPersona() {
        return idPersona;
    }
    public void setIdPersona(String idPersona) {
        this.idPersona = idPersona;
    }
    public String getClabe() {
        return clabe;
    }
    public void setClabe(String clabe) {
        this.clabe = clabe;
    }
    public String getNoCuenta() {
        return noCuenta;
    }
    public void setNoCuenta(String noCuenta) {
        this.noCuenta = noCuenta;
    }
    public boolean getEstadoActivo() {
        return estadoActivo;
    }
    public void setEstadoActivo(boolean estadoActivo) {
        this.estadoActivo = estadoActivo;
    }

}

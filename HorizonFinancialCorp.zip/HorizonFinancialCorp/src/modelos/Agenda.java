/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author crist
 */
public class Agenda {

    private String idAgenda;
    private String idPersona;
    private String noCuentaATransferir;
    private String apodo;
    private boolean estadoActivo;


    private String nombrePersonaATransferir;
    //Por cada entidad estoy creando dos tipos de constructores, dependiendo del que se necesite
    //puede que quitemos uno dependiendo su utilidad

    public Agenda() {

    }


    public Agenda(String idAgenda, String noCuenta, String nombre, String apodo, String idPersona,  boolean estadoActivo) {
        this.idAgenda = idAgenda;
        this.noCuentaATransferir = noCuenta;
        this.nombrePersonaATransferir = nombre;
        this.apodo = apodo;
        this.idPersona = idPersona;
        this.estadoActivo = estadoActivo;
    }

    //Aqui le movi a las 3 am, awas
    public Agenda(String idPersona, String noCuentaDestino, String nombre, boolean b) {
        this.idPersona = idPersona;
        this.noCuentaATransferir = noCuentaDestino;
        this.nombrePersonaATransferir = nombre;
        this.apodo = apodo;
        this.estadoActivo = b;
    }

    //Metodos getters correspondientes a Agenda
    public String getIdAgenda() {
        return idAgenda;
    }
    //aki tambien
    public String getIdPersona()  {
        return idPersona;
    }

    public String getNoCuentaATransferir() {
        return noCuentaATransferir;
    }
    public String getNombrePersonaATransferir() {
        return nombrePersonaATransferir;
    }
    public String getApodo() {
        return apodo;
    }

    public boolean getEstadoActivo(boolean estadoActivo) {
        return estadoActivo;
    }

    public Object getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    

}

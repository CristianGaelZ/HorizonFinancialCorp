package modelos;

import java.util.ArrayList;
import java.util.List;

public class Persona {
    private String idPersona;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String nombreUsuario;
    private String email;
    private String rfc;
    private String tipo;
    private boolean estadoActivo;
    private String password;
    private List<Cuenta> cuentas;
    private String fechaNacimiento;
    private double sueldoAnual;
    private String numeroTarjeta;

    // Constructor
    public Persona(String idPersona, String nombre, String apellidoPaterno, String apellidoMaterno,
                   String nombreUsuario, String email, String rfc, String tipo, boolean estadoActivo,
                   String password, String fechaNacimiento, double sueldoAnual) {
        this.idPersona = idPersona;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.rfc = rfc;
        this.tipo = tipo;
        this.estadoActivo = estadoActivo;
        this.password = password;
        this.fechaNacimiento = fechaNacimiento;
        this.sueldoAnual = sueldoAnual;
        this.cuentas = new ArrayList<>();
    }


    public String generarNoCuenta() {
        return "CU" + (10000000 + (int)(Math.random() * 10000000));
    }

    public String generarNip() {
        return String.valueOf(1000 + (int)(Math.random() * 9000));
    }

    public String generarCvv() {
        return String.valueOf(100 + (int)(Math.random() * 900));
    }

    public String generarFechaVencimiento() {
        return "12/25";
    }

    // Getters y Setters
    public String getIdPersona() { return idPersona; }
    public String getNombre() { return nombre; }
    public String getApellidoPaterno() { return apellidoPaterno; }
    public String getApellidoMaterno() { return apellidoMaterno; }
    public String getNombreUsuario() { return nombreUsuario; }
    public String getEmail() { return email; }
    public void setEmail(String email) {this.email = email;}

    public String getRfc() { return rfc; }
    public String getTipo() { return tipo; }
    public boolean isEstadoActivo() { return estadoActivo; }
    public void setEstadoActivo(boolean estadoActivo) { this.estadoActivo = estadoActivo; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public List<Cuenta> getCuentas() { return cuentas; }
    public void setCuentas(List<Cuenta> cuentas) { this.cuentas = cuentas; }
    public String getFechaNacimiento() { return fechaNacimiento; }
    public String setFechaNacimiento(String nuevaFechaNac) { return fechaNacimiento; }
    public double getSueldoAnual() { return sueldoAnual; }

    // Método para verificar si tiene cuenta de crédito
    public boolean tieneCuentaCredito() {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getTipoCuenta().equals("Crédito")) {
                return true;
            }
        }
        return false;
    }

    // Método para obtener las cuentas de tipo crédito
    public List<Cuenta> obtenerCuentasCredito() {
        List<Cuenta> cuentasCredito = new ArrayList<>();
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getTipoCuenta().equals("Crédito")) {
                cuentasCredito.add(cuenta);
            }
        }
        return cuentasCredito;
    }

    // Método para futuro uso
    public double getLimiteCredito() {
        return 0.0;
    }
    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }
    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }
}

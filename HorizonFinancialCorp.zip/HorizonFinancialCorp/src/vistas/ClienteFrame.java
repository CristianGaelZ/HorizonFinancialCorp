package vistas;

import controlador.ControladorBanco;
import modelos.Persona;
import javax.swing.*;
import java.awt.*;
import vistas.paneles.*;

public class ClienteFrame extends JFrame {
    private ControladorBanco controlador;
    private Persona usuario;

    private PanelTarjetasCliente panelTarjetas;
    private PanelHistorialMovimientos panelHistorial;
    private PanelAhorrosCliente panelAhorros;

    private JTabbedPane tabbedPane;

    public ClienteFrame(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;
        initUI();
    }

    private void initUI() {
        setTitle("Horizon Financial Corp - Bienvenido " + usuario.getNombreUsuario());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();

        PanelCuentasCliente panelCuentas = new PanelCuentasCliente(controlador, usuario, this);
        panelTarjetas = new PanelTarjetasCliente(controlador, usuario);
        panelHistorial = new PanelHistorialMovimientos(controlador, usuario);
        PanelDepositos panelDepositos = new PanelDepositos(controlador, usuario);
        panelAhorros = new PanelAhorrosCliente(controlador, usuario);  // Ahora es atributo

        tabbedPane.addTab("Mis Cuentas", panelCuentas);
        tabbedPane.addTab("Transferencias", new PanelTransferencias(controlador, usuario));
        tabbedPane.addTab("Depósitos", panelDepositos);
        tabbedPane.addTab("Mis Ahorros", panelAhorros);
        tabbedPane.addTab("Mis Tarjetas", panelTarjetas);
        tabbedPane.addTab("Historial de Movimientos", panelHistorial);

        if (tieneCuentaCredito(usuario)) {
            PanelCreditosCliente panelCreditos = new PanelCreditosCliente(controlador, usuario);
            tabbedPane.addTab("Créditos", panelCreditos);
        }

        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> {
            new LoginFrame(controlador).setVisible(true);
            dispose();
        });
        menuArchivo.add(itemSalir);
        menuBar.add(menuArchivo);
        setJMenuBar(menuBar);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        JLabel lblBienvenida = new JLabel("Bienvenido, " + usuario.getNombre(), SwingConstants.LEFT);
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 14));
        panelSuperior.add(lblBienvenida, BorderLayout.WEST);

        JPanel panelBotonesDerecha = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton btnRefresh = new JButton("⟳");
        btnRefresh.setToolTipText("Actualizar datos");
        btnRefresh.setFont(new Font("Arial", Font.PLAIN, 16));
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        btnRefresh.addActionListener(e -> recargarTodo());

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(e -> {
            new LoginFrame(controlador).setVisible(true);
            dispose();
        });

        panelBotonesDerecha.add(btnRefresh);
        panelBotonesDerecha.add(btnCerrarSesion);
        panelSuperior.add(panelBotonesDerecha, BorderLayout.EAST);

        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);
    }

    private boolean tieneCuentaCredito(Persona usuario) {
        return controlador.tieneCuentaCredito(usuario);
    }

    private void recargarTodo() {
        try {

            panelTarjetas.cargarCuentas();

            int indexHistorial = tabbedPane.indexOfTab("Historial de Movimientos");
            if (indexHistorial != -1) {
                panelHistorial = new PanelHistorialMovimientos(controlador, usuario);
                tabbedPane.setComponentAt(indexHistorial, panelHistorial);
            }

            int indexAhorros = tabbedPane.indexOfTab("Mis Ahorros");
            if (indexAhorros != -1) {
                panelAhorros = new PanelAhorrosCliente(controlador, usuario);
                tabbedPane.setComponentAt(indexAhorros, panelAhorros);
            }

            Component panelActual = tabbedPane.getSelectedComponent();
            if (panelActual instanceof PanelCuentasCliente) {
                ((PanelCuentasCliente) panelActual).cargarCuentas();
            }

            JOptionPane.showMessageDialog(this,
                    "Datos actualizados correctamente",
                    "Actualización",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}

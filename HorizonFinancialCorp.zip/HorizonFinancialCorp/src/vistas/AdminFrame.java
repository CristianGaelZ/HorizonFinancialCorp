package vistas;

import controlador.ControladorBanco;
import javax.swing.*;
import java.awt.*;
import modelos.Persona;
import vistas.paneles.PanelGestionCreditos;
import vistas.paneles.PanelGestionUsuarios;
import vistas.paneles.PanelGestionSubgerentes;
import vistas.paneles.PanelGestionCuentas;

public class AdminFrame extends JFrame {
    private ControladorBanco controlador;
    private JTabbedPane tabbedPane;
    private PanelGestionUsuarios panelUsuarios;
    private PanelGestionCreditos panelCreditos;
    private PanelGestionSubgerentes panelSubgerentes;
    private PanelGestionCuentas panelCuentas;

    public AdminFrame(ControladorBanco controlador, Persona admin) {
        this.controlador = controlador;
        initUI();
    }

    private void initUI() {
        setTitle("Horizon Financial Corp - Administración");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        // Crear pestañas
        tabbedPane = new JTabbedPane();

        // Inicializar paneles
        panelUsuarios = new PanelGestionUsuarios(controlador);
        panelSubgerentes = new PanelGestionSubgerentes(controlador);
        panelCreditos = new PanelGestionCreditos(controlador);
        panelCuentas = new PanelGestionCuentas(controlador);

        // Agregar pestañas
        tabbedPane.addTab("Gestión de Usuarios", panelUsuarios);
        tabbedPane.addTab("Gestión de Cuentas", panelCuentas);
        tabbedPane.addTab("Gestión de Subgerentes", panelSubgerentes);
        tabbedPane.addTab("Gestión de Créditos", panelCreditos);

        // Barra de menú
        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0));
        menuArchivo.add(itemSalir);
        menuBar.add(menuArchivo);
        setJMenuBar(menuBar);

        // Panel superior con botones
        JPanel panelSuperior = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Panel de Administración", SwingConstants.LEFT);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        panelSuperior.add(lblTitulo, BorderLayout.WEST);

        // Botones a la derecha
        JPanel panelBotonesDerecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
        JButton btnRefresh = new JButton("Actualizar");
        btnRefresh.setToolTipText("Actualizar todos los datos");
        btnRefresh.setFont(new Font("Arial", Font.PLAIN, 16));
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        btnRefresh.addActionListener(e -> recargarPaneles());

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(e -> {
            new LoginFrame(controlador).setVisible(true);
            dispose();
        });

        panelBotonesDerecha.add(btnRefresh);
        panelBotonesDerecha.add(btnCerrarSesion);
        panelSuperior.add(panelBotonesDerecha, BorderLayout.EAST);

        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);
    }

    private void recargarPaneles() {
        try {
            panelUsuarios = new PanelGestionUsuarios(controlador);
            panelCuentas = new PanelGestionCuentas(controlador);
            panelSubgerentes = new PanelGestionSubgerentes(controlador);
            panelCreditos = new PanelGestionCreditos(controlador);

            tabbedPane.setComponentAt(0, panelUsuarios);
            tabbedPane.setComponentAt(1, panelCuentas);
            tabbedPane.setComponentAt(2, panelSubgerentes);
            tabbedPane.setComponentAt(3, panelCreditos);

            JOptionPane.showMessageDialog(this,
                    "Todos los paneles administrativos han sido actualizados",
                    "Actualización completada",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar los paneles: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}

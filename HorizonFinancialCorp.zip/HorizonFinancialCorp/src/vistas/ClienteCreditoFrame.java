package vistas;

import controlador.ControladorBanco;
import modelos.Persona;
import vistas.paneles.*;

import javax.swing.*;
import java.awt.*;

public class ClienteCreditoFrame extends JFrame {
    private ControladorBanco controlador;
    private Persona persona;
    private PanelTarjetasCliente panelTarjetas;
    private PanelHistorialMovimientos panelHistorial;
    private JTabbedPane clienteTabs;
    private JTabbedPane creditosTabs;

    public ClienteCreditoFrame(ControladorBanco controlador, Persona persona) {
        this.controlador = controlador;
        this.persona = persona;
        initUI();
    }

    private void initUI() {
        setTitle("Horizon Financial Corp - Créditos y Operaciones del Cliente");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 650);
        setLocationRelativeTo(null);

        // ---------- CREDITOS ----------
        creditosTabs = new JTabbedPane();
        creditosTabs.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        creditosTabs.addTab("Solicitar Crédito", new PanelSolicitarCredito(controlador, persona));
        creditosTabs.addTab("Pagar Crédito", new PanelPagoCredito(controlador, persona));
        creditosTabs.addTab("Historial de Créditos", new PanelHistorialCreditos(controlador, persona));

        // ---------- CLIENTE ----------
        clienteTabs = new JTabbedPane();
        clienteTabs.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        PanelCuentasCliente panelCuentas = new PanelCuentasCliente(controlador, persona, null);
        panelTarjetas = new PanelTarjetasCliente(controlador, persona);
        panelHistorial = new PanelHistorialMovimientos(controlador, persona);
        PanelDepositos panelDepositos = new PanelDepositos(controlador, persona);
        PanelTransferencias panelTransferencias = new PanelTransferencias(controlador, persona);
        PanelAhorrosCliente panelAhorros = new PanelAhorrosCliente(controlador, persona); // Nuevo panel

        clienteTabs.addTab("Mis Cuentas", panelCuentas);
        clienteTabs.addTab("Transferencias", panelTransferencias);
        clienteTabs.addTab("Depósitos", panelDepositos);
        clienteTabs.addTab("Mis Ahorros", panelAhorros);
        clienteTabs.addTab("Mis Tarjetas", panelTarjetas);
        clienteTabs.addTab("Historial de Movimientos", panelHistorial);

        // ---------- SPLITPANE ----------
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, creditosTabs, clienteTabs);
        splitPane.setResizeWeight(0.5);
        splitPane.setDividerLocation(600);

        // ---------- MENU Y HEADER ----------
        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemCerrarSesion = new JMenuItem("Cerrar Sesión");
        itemCerrarSesion.addActionListener(e -> {
            dispose();
            new LoginFrame(controlador).setVisible(true);
        });
        menuArchivo.add(itemCerrarSesion);
        menuBar.add(menuArchivo);
        setJMenuBar(menuBar);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        JLabel lblBienvenida = new JLabel("Bienvenido, " + persona.getNombre(), SwingConstants.LEFT);
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 14));
        panelSuperior.add(lblBienvenida, BorderLayout.WEST);

        JPanel panelBotonesDerecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
        JButton btnRefresh = new JButton("Actualizar");
        btnRefresh.setToolTipText("Actualizar todos los datos");
        btnRefresh.setFont(new Font("Arial", Font.PLAIN, 12));
        btnRefresh.setBackground(new Color(240, 240, 240));
        btnRefresh.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btnRefresh.addActionListener(e -> recargarTodosLosPaneles());

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(e -> {
            new LoginFrame(controlador).setVisible(true);
            dispose();
        });

        panelBotonesDerecha.add(btnRefresh);
        panelBotonesDerecha.add(btnCerrarSesion);
        panelSuperior.add(panelBotonesDerecha, BorderLayout.EAST);

        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void recargarTodosLosPaneles() {
        try {
            panelTarjetas.cargarCuentas();

            int indexHistorial = clienteTabs.indexOfTab("Historial de Movimientos");
            if (indexHistorial != -1) {
                panelHistorial = new PanelHistorialMovimientos(controlador, persona);
                clienteTabs.setComponentAt(indexHistorial, panelHistorial);
            }

            int indexHistorialCreditos = creditosTabs.indexOfTab("Historial de Créditos");
            if (indexHistorialCreditos != -1) {
                PanelHistorialCreditos panelHistorialCreditos = new PanelHistorialCreditos(controlador, persona);
                creditosTabs.setComponentAt(indexHistorialCreditos, panelHistorialCreditos);
            }

            JOptionPane.showMessageDialog(this,
                    "Todos los datos han sido actualizados",
                    "Actualización completada",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void recargarTarjetas() {
        panelTarjetas.cargarCuentas();
    }

    public void actualizarTarjetas() {
        panelTarjetas = new PanelTarjetasCliente(controlador, persona);
    }
}

package vistas;

import controlador.ControladorBanco;
import modelos.Persona;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private ControladorBanco controlador;

    public LoginFrame(ControladorBanco controlador) {
        this.controlador = controlador;
        initComponents();
    }

    private void initComponents() {
        setTitle("Inicio de Sesión");
        setSize(350, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setResizable(false);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblTitulo = new JLabel("Bienvenido al Banco", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCampos = new JPanel(new GridLayout(2, 2, 10, 10));
        panelCampos.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField("admin");
        panelCampos.add(txtUsuario);

        panelCampos.add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField("1234");
        panelCampos.add(txtPassword);

        panelPrincipal.add(panelCampos, BorderLayout.CENTER);


        JButton btnLogin = new JButton("Iniciar Sesión");
        btnLogin.addActionListener(e -> realizarLogin());

        JButton btnRegresar = new JButton("Regresar");
        btnRegresar.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> new RetiroInicioFrame(controlador).setVisible(true));
            dispose();
        });

        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBoton.add(btnLogin);
        panelBoton.add(btnRegresar);

        panelPrincipal.add(panelBoton, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private void realizarLogin() {
        String usuario = txtUsuario.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();


        if (usuario.equals("admin") && password.equals("1234")) {
            new AdminFrame(controlador, null).setVisible(true);
            dispose();
            return;
        }


        Persona persona = controlador.encontrarUsuario(usuario, password);
        if (persona != null && "subgerente".equals(persona.getTipo())) {
            new SubGerenteFrame(controlador, persona).setVisible(true);
            dispose();
            return;
        }

        if (persona != null) {
            JFrame destino;
            if (controlador.tieneCuentaCredito(persona)) {
                destino = new ClienteCreditoFrame(controlador, persona);
            } else {
                destino = new ClienteFrame(controlador, persona);
            }
            destino.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public JTextField getUsuarioField() {
        return txtUsuario;
    }

    public JPasswordField getContraseñaField() {
        return txtPassword;
    }
}

package vistas;

import controlador.ControladorBanco;
import vistas.paneles.PanelRetiros;

import javax.swing.*;
import java.awt.*;

public class RetiroInicioFrame extends JFrame {

    public RetiroInicioFrame(ControladorBanco controlador) {
        setTitle("Retiros - Bienvenido");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnLogin = new JButton("Inicio de Sesión");
        btnLogin.setFocusPainted(false);
        btnLogin.addActionListener(e -> {
            new LoginFrame(controlador).setVisible(true);
            dispose();
        });

        panelSuperior.add(btnLogin, BorderLayout.EAST);
        add(panelSuperior, BorderLayout.NORTH);

        PanelRetiros panelRetiros = new PanelRetiros(controlador, null);
        add(panelRetiros, BorderLayout.CENTER);
    }
}

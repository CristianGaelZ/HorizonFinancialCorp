package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Transferencias;
import modelos.Deposito;
import modelos.Persona;
import modelos.Retiro;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelHistorialMovimientos extends JPanel {

    private ControladorBanco controlador;
    private Persona usuario;

    private JTable tablaTransferencias;
    private JTable tablaDepositos;
    private JTable tablaRetiros;

    private DefaultTableModel modeloTransferencias;
    private DefaultTableModel modeloDepositos;
    private DefaultTableModel modeloRetiros;

    public PanelHistorialMovimientos(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        setLayout(new GridLayout(3, 1, 10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        initTablaTransferencias();
        initTablaDepositos();
        initTablaRetiros();

        cargarHistorialTransferencias();
        cargarHistorialDepositos();
        cargarHistorialRetiros();
    }

    private void initTablaTransferencias() {
        String[] columnas = { "ID", "Monto", "Cuenta Origen", "Cuenta Destino", "CLABE Origen", "CLABE Destino", "Fecha" };
        modeloTransferencias = new DefaultTableModel(columnas, 0);
        tablaTransferencias = new JTable(modeloTransferencias);

        JScrollPane scroll = new JScrollPane(tablaTransferencias);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Transferencias realizadas",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));

        add(scroll);
    }

    private void initTablaDepositos() {
        String[] columnas = { "ID", "Monto", "Cuenta Destino", "Número Tarjeta", "Fecha" };
        modeloDepositos = new DefaultTableModel(columnas, 0);
        tablaDepositos = new JTable(modeloDepositos);

        JScrollPane scroll = new JScrollPane(tablaDepositos);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Depósitos realizados",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));

        add(scroll);
    }

    private void initTablaRetiros() {
        String[] columnas = { "ID", "Monto", "Cuenta Origen", "Número Tarjeta", "Fecha" };
        modeloRetiros = new DefaultTableModel(columnas, 0);
        tablaRetiros = new JTable(modeloRetiros);

        JScrollPane scroll = new JScrollPane(tablaRetiros);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Retiros realizados",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));

        add(scroll);
    }

    private void cargarHistorialTransferencias() {
        modeloTransferencias.setRowCount(0);
        List<Transferencias> transferencias = controlador.obtenerHistorialTransferencias(usuario.getIdPersona());

        for (Transferencias t : transferencias) {
            Object[] fila = {
                    t.getIdTransferencia(),
                    t.getMonto(),
                    t.getNoCuentaEnvio(),
                    t.getNoCuentaDestino(),
                    t.getClabeEnvio(),
                    t.getClabeDestino(),
                    t.getFechaHora()
            };
            modeloTransferencias.addRow(fila);
        }
    }

    private void cargarHistorialDepositos() {
        modeloDepositos.setRowCount(0);
        List<Deposito> depositos = controlador.obtenerHistorialDepositos(usuario.getIdPersona());

        for (Deposito d : depositos) {
            Object[] fila = {
                    d.getIdDeposito(),
                    d.getMonto(),
                    d.getNoCuentaDestino(),
                    d.getNumeroTarjetaDestino(),
                    d.getFechaHora()
            };
            modeloDepositos.addRow(fila);
        }
    }

    private void cargarHistorialRetiros() {
        modeloRetiros.setRowCount(0);

        List<Retiro> retiros = controlador.obtenerHistorialRetiros(usuario.getIdPersona());
        for (Retiro r : retiros) {
            Object[] fila = {
                    r.getIdRetiro(),
                    r.getMonto(),
                    r.getNoCuentaOrigen(),
                    r.getNumeroTarjetaOrigen(),
                    r.getFechaHora()
            };
            modeloRetiros.addRow(fila);
        }
    }
}

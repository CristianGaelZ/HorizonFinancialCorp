package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Cuenta;
import modelos.Persona;
import vistas.ClienteCreditoFrame;
import vistas.ClienteFrame;
import vistas.LoginFrame;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PanelGestionUsuarios extends JPanel {
    private ControladorBanco controlador;
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;

    public PanelGestionUsuarios(ControladorBanco controlador) {
        this.controlador = controlador;
        initComponents();
        agregarUsuariosDePrueba();
        cargarUsuarios();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton btnAgregar = new JButton("Agregar Usuario");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnSalir = new JButton("Salir");

        btnAgregar.addActionListener(this::agregarUsuario);
        btnEditar.addActionListener(this::editarUsuario);
        btnEliminar.addActionListener(this::eliminarUsuario);
        btnSalir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Estás seguro de que deseas cerrar sesión?",
                    "Cerrar Sesión",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (opcion == JOptionPane.YES_OPTION) {
                JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
                topFrame.dispose();

                SwingUtilities.invokeLater(() -> new LoginFrame(controlador).setVisible(true));
            }
        });

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnSalir);

        add(panelBotones, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Usuario", "Email", "Tipo", "RFC","Fecha Nacimiento", "Contraseña"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaUsuarios = new JTable(modeloTabla);
        tablaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tablaUsuarios);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void eliminarUsuario(ActionEvent e) {
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar este usuario?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            String idPersona = modeloTabla.getValueAt(filaSeleccionada, 0).toString();
            Persona usuario = controlador.buscarPersonaPorId(idPersona);
            if (usuario != null) {
                usuario.setEstadoActivo(false); // Desactivamos el usuario en vez de eliminarlo físicamente
                controlador.actualizarPersona(usuario);
                cargarUsuarios();
                JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private void editarUsuario(ActionEvent e) {
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idPersona = modeloTabla.getValueAt(filaSeleccionada, 0).toString();
        Persona usuario = controlador.buscarPersonaPorId(idPersona);

        if (usuario == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nuevoEmail = JOptionPane.showInputDialog(this, "Editar Email:", usuario.getEmail());
        if (nuevoEmail == null || nuevoEmail.trim().isEmpty()) return;

        String nuevaFechaNac = JOptionPane.showInputDialog(this, "Editar Fecha Nacimiento (YYYY-MM-DD):", usuario.getFechaNacimiento());
        if (nuevaFechaNac == null || nuevaFechaNac.trim().isEmpty()) return;

        String nuevoPassword = JOptionPane.showInputDialog(this, "Editar Contraseña:", usuario.getPassword());
        if (nuevoPassword == null || nuevoPassword.trim().isEmpty()) return;

        if (!validarEmail(nuevoEmail)) {
            JOptionPane.showMessageDialog(this, "Email inválido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        usuario.setEmail(nuevoEmail);
        usuario.setFechaNacimiento(nuevaFechaNac);
        usuario.setPassword(nuevoPassword);
        controlador.actualizarPersona(usuario); // Asegúrate de tener este método en tu controlador
        cargarUsuarios();
        JOptionPane.showMessageDialog(this, "Usuario actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }


    private void cargarUsuarios() {
        modeloTabla.setRowCount(0);
        ArrayList<Persona> usuarios = (ArrayList<Persona>) controlador.getListaPersonas();
        for (Persona usuario : usuarios) {
            // Excluir subgerentes (!"subgerente".equals(usuario.getTipo()))
            if (usuario.isEstadoActivo() && !"subgerente".equals(usuario.getTipo())) {
                Object[] fila = {
                        usuario.getIdPersona(),
                        usuario.getNombre() + " " + usuario.getApellidoPaterno() + " " + usuario.getApellidoMaterno(),
                        usuario.getNombreUsuario(),
                        usuario.getEmail(),
                        usuario.getTipo().equals("1") ? "Física" : "Moral",
                        usuario.getRfc(),
                        usuario.getFechaNacimiento(), // Mostramos la fecha de nacimiento
                        usuario.getPassword()
                };
                modeloTabla.addRow(fila);
            }
        }
    }

    private void agregarUsuariosDePrueba() {
        String[] nombres = {"Maria Raquel", "Luis", "Carlos"};
        String[] apellidos = {"Ortiz Alvares", "Hernández", "Martínez"};
        String[] emails = {"raquel@gmail.com", "luis@test.com", "carlos@test.com"};
        String[] rfcs = {"RAQL930101ABC", "HERN850202XYZ", "MART990303LMN"};
        String[] usuarios = {"Raquel01", "luis85", "carlos99"};
        String[] tipos = {"1", "1", "2"}; // 1 = Física, 2 = Moral
        String[] passwords = {"pass123", "pass456", "pass789"};
        String[] fechasNacimiento = {"1993-01-01", "1985-02-02", "1999-03-03"};
        double[] sueldos = {40000, 120000, 80000};
        String[] tiposCuenta = {"Débito", "Debito", "Debito"};


        String[] cuentasEstaticas = {
                "4111 0012 3456 7890",
                "5312 3412 87654 321",
                "6762 0512 3456 7898"
        };

        String[] tarjetasEstaticas = {
                "4111 0012 3456 7890",
                "5312 3412 87654 321",
                "6762 0512 3456 7898"
        };

        for (int i = 0; i < 3; i++) {
            String idPersona = String.valueOf(System.currentTimeMillis() + i);
            String nombre = nombres[i];
            String apellido = apellidos[i];
            String email = emails[i];
            String rfc = rfcs[i];
            String usuario = usuarios[i];
            String tipo = tipos[i];
            String password = passwords[i];
            String fechaNacimiento = fechasNacimiento[i];
            double sueldo = sueldos[i];
            String tipoCuenta = tiposCuenta[i % tiposCuenta.length];
            double montoInicial = tipoCuenta.equals("Crédito") ? calcularLineaCredito(sueldo) : sueldo * 0.1;

            boolean exito = controlador.agregarPersona(
                    idPersona, nombre, apellido, "Lopez",
                    usuario, email, rfc, tipo, true,
                    password, fechaNacimiento, sueldo
            );

            if (exito) {
                Cuenta cuenta = new Cuenta(
                        idPersona,
                        cuentasEstaticas[i],
                        montoInicial,
                        generarClabe(),
                        tipoCuenta,
                        true,
                        Cuenta.generarNip(),
                        Cuenta.generarCvv(),
                        Cuenta.generarFechaVencimiento(),
                        tarjetasEstaticas[i]
                );
                controlador.agregarCuenta(cuenta);
            }
        }
    }



    private void agregarUsuario(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Registrar Nuevo Usuario");
        dialog.setModal(true);
        dialog.setSize(500, 650);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField(15);
        JLabel lblApellidoPaterno = new JLabel("Apellido Paterno:");
        JTextField txtApellidoPaterno = new JTextField(15);
        JLabel lblApellidoMaterno = new JLabel("Apellido Materno:");
        JTextField txtApellidoMaterno = new JTextField(15);
        JLabel lblUsuario = new JLabel("Nombre de Usuario:");
        JTextField txtUsuario = new JTextField(15);
        JLabel lblRFC = new JLabel("RFC:");
        JTextField txtRFC = new JTextField(15);
        JLabel lblEmail = new JLabel("Email:");
        JTextField txtEmail = new JTextField(15);
        JLabel lblPassword = new JLabel("Contraseña:");
        JPasswordField txtPassword = new JPasswordField(15);
        JLabel lblFechaNacimiento = new JLabel("Fecha de Nacimiento (YYYY-MM-DD):");
        JTextField txtFechaNacimiento = new JTextField(15);
        JLabel lblSueldo = new JLabel("Sueldo Anual:");
        JTextField txtSueldo = new JTextField(15);
        JLabel lblTipoCuenta = new JLabel("Tipo de Cuenta:");
        String[] tiposCuenta = {"Débito", "Crédito", "Ahorro"};
        JComboBox<String> comboTipoCuenta = new JComboBox<>(tiposCuenta);
        JLabel lblMontoInicial = new JLabel("Monto Inicial:");
        JTextField txtMontoInicial = new JTextField(15);
        JLabel lblCreditoAsignado = new JLabel("Crédito Asignado:");
        JTextField txtCreditoAsignado = new JTextField(15);
        txtCreditoAsignado.setEditable(false);
        txtCreditoAsignado.setBackground(new Color(240, 240, 240));
        JLabel lblTipo = new JLabel("Tipo de Persona:");
        ButtonGroup bgTipo = new ButtonGroup();
        JRadioButton rbFisica = new JRadioButton("Física", true);
        JRadioButton rbMoral = new JRadioButton("Moral");
        bgTipo.add(rbFisica);
        bgTipo.add(rbMoral);

        JPanel panelTipo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelTipo.add(rbFisica);
        panelTipo.add(rbMoral);


        txtSueldo.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { calcularCredito(); }
            public void removeUpdate(DocumentEvent e) { calcularCredito(); }
            public void insertUpdate(DocumentEvent e) { calcularCredito(); }

            private void calcularCredito() {
                try {
                    double sueldoAnual = Double.parseDouble(txtSueldo.getText().trim());
                    String tipoCuenta = comboTipoCuenta.getSelectedItem().toString();

                    if (tipoCuenta.equals("Crédito")) {
                        double credito = calcularLineaCredito(sueldoAnual);
                        txtCreditoAsignado.setText(String.format("$%,.2f", credito));
                        txtMontoInicial.setText(String.valueOf(credito));
                    } else {
                        txtCreditoAsignado.setText("$0.00");
                    }
                } catch (NumberFormatException ex) {
                    txtCreditoAsignado.setText("$0.00");
                }
            }
        });

        comboTipoCuenta.addActionListener(evt -> {
            if (comboTipoCuenta.getSelectedItem().toString().equals("Crédito") && !txtSueldo.getText().isEmpty()) {
                try {
                    double sueldoAnual = Double.parseDouble(txtSueldo.getText().trim());
                    double credito = calcularLineaCredito(sueldoAnual);
                    txtCreditoAsignado.setText(String.format("$%,.2f", credito));
                    txtMontoInicial.setText(String.valueOf(credito));
                } catch (NumberFormatException ex) {
                    txtCreditoAsignado.setText("$0.00");
                }
            } else {
                txtCreditoAsignado.setText("$0.00");
            }
        });

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(ev -> {
            String tipoPersona = rbFisica.isSelected() ? "1" : "2";
            String rfc = txtRFC.getText().trim().toUpperCase();

            if (!validarRFC(rfc, tipoPersona)) {
                JOptionPane.showMessageDialog(dialog, "RFC inválido", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String email = txtEmail.getText().trim();
            if (!validarEmail(email)) {
                JOptionPane.showMessageDialog(dialog, "Email inválido", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String idPersona = String.valueOf(System.currentTimeMillis());
            String numeroCuenta = generarNoCuenta();
            String clabe = generarClabe();
            String nip = Cuenta.generarNip();
            String cvv = Cuenta.generarCvv();
            String fechaVencimiento = Cuenta.generarFechaVencimiento();

            String nombre = txtNombre.getText().trim();
            String apellidoPaterno = txtApellidoPaterno.getText().trim();
            String apellidoMaterno = txtApellidoMaterno.getText().trim();
            String nombreUsuario = txtUsuario.getText().trim();
            String password = new String(txtPassword.getPassword());
            String fechaNacimiento = txtFechaNacimiento.getText().trim();
            double sueldoAnual = Double.parseDouble(txtSueldo.getText().trim());
            String tipoCuenta = comboTipoCuenta.getSelectedItem().toString();

            double saldoInicial;
            try {
                if (tipoCuenta.equals("Crédito")) {
                    saldoInicial = calcularLineaCredito(sueldoAnual);
                } else {
                    saldoInicial = Double.parseDouble(txtMontoInicial.getText().trim());
                    if (saldoInicial < 0) throw new NumberFormatException();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Ingrese un monto inicial válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = controlador.agregarPersona(
                    idPersona,
                    nombre,
                    apellidoPaterno,
                    apellidoMaterno,
                    nombreUsuario,
                    email,
                    rfc,
                    tipoPersona,
                    true,
                    password,
                    fechaNacimiento,
                    sueldoAnual
            );

            if (success) {
                Persona persona = new Persona(
                        idPersona,
                        nombre,
                        apellidoPaterno,
                        apellidoMaterno,
                        nombreUsuario,
                        email,
                        rfc,
                        tipoPersona,
                        true,
                        password,
                        fechaNacimiento,
                        sueldoAnual
                );

                Cuenta nuevaCuenta = new Cuenta(
                        idPersona,
                        numeroCuenta,
                        saldoInicial,
                        clabe,
                        tipoCuenta,
                        true,
                        nip,
                        cvv,
                        fechaVencimiento,
                        generarNumeroTarjeta()
                );

                controlador.agregarCuenta(nuevaCuenta);

                dialog.dispose();
                cargarUsuarios();
                JOptionPane.showMessageDialog(dialog, "Usuario registrado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(dialog, "El RFC ya está registrado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblNombre, gbc); gbc.gridx = 1; panel.add(txtNombre, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblApellidoPaterno, gbc); gbc.gridx = 1; panel.add(txtApellidoPaterno, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblApellidoMaterno, gbc); gbc.gridx = 1; panel.add(txtApellidoMaterno, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblUsuario, gbc); gbc.gridx = 1; panel.add(txtUsuario, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblRFC, gbc); gbc.gridx = 1; panel.add(txtRFC, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblEmail, gbc); gbc.gridx = 1; panel.add(txtEmail, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblPassword, gbc); gbc.gridx = 1; panel.add(txtPassword, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblFechaNacimiento, gbc); gbc.gridx = 1; panel.add(txtFechaNacimiento, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblSueldo, gbc); gbc.gridx = 1; panel.add(txtSueldo, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblTipoCuenta, gbc); gbc.gridx = 1; panel.add(comboTipoCuenta, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblMontoInicial, gbc); gbc.gridx = 1; panel.add(txtMontoInicial, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblCreditoAsignado, gbc); gbc.gridx = 1; panel.add(txtCreditoAsignado, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblTipo, gbc); gbc.gridx = 1; panel.add(panelTipo, gbc); y++;
        gbc.gridx = 1; gbc.gridy = y; panel.add(btnGuardar, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private double calcularLineaCredito(double sueldoAnual) {
        if (sueldoAnual <= 50000) {
            return 3000;
        } else if (sueldoAnual > 50000 && sueldoAnual <= 100000) {
            return 10000;
        } else if (sueldoAnual > 100000 && sueldoAnual <= 300000) {
            return 30000;
        } else {
            return 100000;
        }
    }

    private boolean validarRFC(String rfc, String tipoPersona) {
        String regexFisica = "[A-Z&Ñ]{4}\\d{6}[A-Z0-9]{3}";
        String regexMoral = "[A-Z&Ñ]{3}\\d{6}[A-Z0-9]{3}";
        Pattern pattern = Pattern.compile(tipoPersona.equals("1") ? regexFisica : regexMoral);
        Matcher matcher = pattern.matcher(rfc);
        return matcher.matches();
    }

    private boolean validarEmail(String email) {
        String regexEmail = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(regexEmail);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private String generarNoCuenta() {
        return "41" + System.currentTimeMillis();
    }

    private String generarClabe() {
        StringBuilder clabe = new StringBuilder("01");
        Random rand = new Random();
        for (int i = 0; i < 16; i++) {
            clabe.append(rand.nextInt(10));
        }
        return clabe.toString();
    }

    private String generarNumeroTarjeta() {
        StringBuilder tarjeta = new StringBuilder("4169");
        Random rand = new Random();
        for (int i = 0; i < 12; i++) {
            tarjeta.append(rand.nextInt(10));
        }
        return tarjeta.toString();
    }
}
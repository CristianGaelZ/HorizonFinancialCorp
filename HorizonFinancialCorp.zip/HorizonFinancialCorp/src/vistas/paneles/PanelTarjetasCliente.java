package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Cuenta;
import modelos.Persona;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelTarjetasCliente extends JPanel {

    private ControladorBanco controlador;
    private Persona usuario;
    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public PanelTarjetasCliente(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        setLayout(new BorderLayout());
        initTabla();
        cargarCuentas();
    }

    private void initTabla() {
        String[] columnas = { "Tipo", "Tarjeta", "CLABE", "CVV", "Vencimiento", "Saldo" };
        modeloTabla = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void cargarCuentas() {
        modeloTabla.setRowCount(0);

        if (usuario != null) {
            List<Cuenta> cuentas = controlador.obtenerCuentasCliente(usuario.getIdPersona());

            for (Cuenta cuenta : cuentas) {
                Object[] fila = {
                        cuenta.getTipoCuenta(),
                        cuenta.getNumeroTarjeta(),
                        cuenta.getClabe(),
                        cuenta.getCvv(),
                        cuenta.getFechaVencimiento(),
                        cuenta.getSaldo()
                };
                modeloTabla.addRow(fila);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error: El usuario es null. No se pueden cargar las cuentas.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

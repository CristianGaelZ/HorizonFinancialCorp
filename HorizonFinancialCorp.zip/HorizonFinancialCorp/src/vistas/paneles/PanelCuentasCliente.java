package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Cuenta;
import modelos.Persona;
import vistas.ClienteFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class PanelCuentasCliente extends JPanel {
    private ControladorBanco controlador;
    private Persona usuario;
    private ClienteFrame clienteFrame;
    private JPanel panelTarjetas;

    public PanelCuentasCliente(ControladorBanco controlador, Persona usuario, ClienteFrame clienteFrame) {
        this.controlador = controlador;
        this.usuario = usuario;
        this.clienteFrame = clienteFrame;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnNuevaCuenta = new JButton("Abrir Nueva Cuenta");
        btnNuevaCuenta.addActionListener(this::abrirNuevaCuenta);
        panelBotones.add(btnNuevaCuenta);
        add(panelBotones, BorderLayout.NORTH);

        panelTarjetas = new JPanel(new GridLayout(0, 3, 10, 10));
        panelTarjetas.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        cargarCuentasVisuales();

        JScrollPane scrollPane = new JScrollPane(panelTarjetas);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void cargarCuentasVisuales() {
        panelTarjetas.removeAll();

        for (Cuenta cuenta : usuario.getCuentas()) {
            agregarTarjetaVisual(cuenta);
        }

        panelTarjetas.revalidate();
        panelTarjetas.repaint();
    }

    private void abrirNuevaCuenta(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Abrir Nueva Cuenta");
        dialog.setModal(true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTipo = new JLabel("Tipo de Cuenta:");
        ButtonGroup bgTipo = new ButtonGroup();
        JRadioButton rbDebito = new JRadioButton("Débito", true);
        JRadioButton rbCredito = new JRadioButton("Crédito");
        JRadioButton rbInversion = new JRadioButton("Inversión");
        bgTipo.add(rbDebito);
        bgTipo.add(rbCredito);
        bgTipo.add(rbInversion);

        JPanel panelTipo = new JPanel(new GridLayout(0, 1));
        panelTipo.add(rbDebito);
        panelTipo.add(rbCredito);
        panelTipo.add(rbInversion);

        JLabel lblMonto = new JLabel("Monto Inicial:");
        JTextField txtMonto = new JTextField(10);

        JLabel lblCreditoDado = new JLabel("Crédito Dado:");
        JTextField txtCreditoDado = new JTextField(10);
        txtCreditoDado.setEditable(false);

        ActionListener tipoListener = eTipo -> {
            if (rbCredito.isSelected()) {
                double sueldo = usuario.getSueldoAnual();
                double credito = 0;

                if (sueldo <= 50000) {
                    credito = 3000;
                } else if (sueldo <= 100000) {
                    credito = 10000;
                } else if (sueldo <= 300000) {
                    credito = 30000;
                } else {
                    credito = 100000;
                }

                txtCreditoDado.setText(String.valueOf(credito));
                txtMonto.setText(String.valueOf(credito));
                txtMonto.setEditable(false);
                lblCreditoDado.setVisible(true);
                txtCreditoDado.setVisible(true);
            } else {
                txtCreditoDado.setText("");
                txtMonto.setText("");
                txtMonto.setEditable(true);
                lblCreditoDado.setVisible(false);
                txtCreditoDado.setVisible(false);
            }
        };

        rbDebito.addActionListener(tipoListener);
        rbCredito.addActionListener(tipoListener);
        rbInversion.addActionListener(tipoListener);
        tipoListener.actionPerformed(null);

        JButton btnAbrir = new JButton("Abrir Cuenta");
        btnAbrir.addActionListener(ev -> {
            try {
                String tipoCuenta = rbDebito.isSelected() ? "Débito" : rbCredito.isSelected() ? "Crédito" : "Inversión";
                double monto = Double.parseDouble(txtMonto.getText());

                if (yaTieneCuentaTipo(tipoCuenta)) {
                    JOptionPane.showMessageDialog(dialog, "Ya tienes una cuenta de tipo " + tipoCuenta, "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Cuenta nuevaCuenta = Cuenta.crearCuenta(usuario.getIdPersona(), tipoCuenta);
                nuevaCuenta.setNumeroTarjeta(generarNumeroTarjeta());
                nuevaCuenta.setClabe(generarCLABE());
                nuevaCuenta.setCvv(String.format("%03d", new Random().nextInt(1000)));
                nuevaCuenta.setFechaVencimiento(generarVencimiento());
                nuevaCuenta.setSaldo(monto);

                usuario.getCuentas().add(nuevaCuenta);
                agregarTarjetaVisual(nuevaCuenta);
                panelTarjetas.revalidate();
                panelTarjetas.repaint();

                controlador.agregarCuenta(nuevaCuenta);


                if ("Inversión".equalsIgnoreCase(nuevaCuenta.getTipoCuenta())) {
                    iniciarInteresInversion(nuevaCuenta);
                }

                JOptionPane.showMessageDialog(dialog, "Cuenta creada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Monto inválido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblTipo, gbc);
        gbc.gridx = 1;
        panel.add(panelTipo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblMonto, gbc);
        gbc.gridx = 1;
        panel.add(txtMonto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblCreditoDado, gbc);
        gbc.gridx = 1;
        panel.add(txtCreditoDado, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panel.add(btnAbrir, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void iniciarInteresInversion(Cuenta cuentaInversion) {
        Timer timer = new Timer(10000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cuentaInversion.setSaldo(cuentaInversion.getSaldo() + 5);
                cargarCuentasVisuales();
            }
        });
        timer.start();
    }

    private void agregarTarjetaVisual(Cuenta cuenta) {
        JPanel tarjeta = new JPanel();
        tarjeta.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        tarjeta.setBackground(new Color(240, 248, 255));
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setPreferredSize(new Dimension(250, 120));

        tarjeta.add(new JLabel("\uD83D\uDCB3 Tipo: " + cuenta.getTipoCuenta()));
        tarjeta.add(new JLabel("N° Tarjeta: " + cuenta.getNumeroTarjeta()));
        tarjeta.add(new JLabel("CLABE: " + cuenta.getClabe()));
        tarjeta.add(new JLabel("CVV: " + cuenta.getCvv()));
        tarjeta.add(new JLabel("Vence: " + cuenta.getFechaVencimiento()));
        tarjeta.add(new JLabel("Saldo: $" + cuenta.getSaldo()));

        panelTarjetas.add(tarjeta);
    }

    private String generarNumeroTarjeta() {
        StringBuilder sb = new StringBuilder();
        sb.append("4169 ");
        for (int i = 0; i < 12; i++) {
            sb.append((int) (Math.random() * 10));
            if ((i + 1) % 4 == 0 && i < 11) sb.append(" ");
        }
        return sb.toString();
    }

    private String generarCLABE() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 18; i++) {
            sb.append((int) (Math.random() * 10));
        }
        return sb.toString();
    }

    private String generarVencimiento() {
        int mes = 1 + (int)(Math.random() * 12);
        int anio = 2025 + (int)(Math.random() * 5);
        return String.format("%02d/%d", mes, anio);
    }

    private boolean yaTieneCuentaTipo(String tipoCuenta) {
        return usuario.getCuentas().stream().anyMatch(c -> c.getTipoCuenta().equalsIgnoreCase(tipoCuenta));
    }

    public void cargarCuentas() {
    }
}

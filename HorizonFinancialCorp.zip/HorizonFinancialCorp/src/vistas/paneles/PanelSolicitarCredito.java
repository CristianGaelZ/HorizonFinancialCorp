package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Credito;
import modelos.Cuenta;
import modelos.Persona;
import vistas.LoginFrame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class PanelSolicitarCredito extends JPanel {
    private ControladorBanco controlador;
    private Persona persona;

    public PanelSolicitarCredito(ControladorBanco controlador, Persona persona) {
        this.controlador = controlador;
        this.persona = persona;
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(new EmptyBorder(10, 20, 10, 20));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Solicitud de Crédito");
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(new EmptyBorder(5, 0, 10, 0));
        panelPrincipal.add(titulo);

        JPanel panelFormulario = new JPanel(new GridLayout(3, 2, 10, 10));
        panelFormulario.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Datos del Crédito",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.PLAIN, 12),
                Color.DARK_GRAY
        ));
        panelFormulario.setBackground(new Color(245, 245, 245));

        panelFormulario.add(new JLabel("Monto solicitado:"));
        JTextField txtMonto = new JTextField();
        txtMonto.setPreferredSize(new Dimension(120, 24));
        panelFormulario.add(txtMonto);

        panelFormulario.add(new JLabel("Plazo (meses):"));
        JTextField txtPlazo = new JTextField();
        txtPlazo.setPreferredSize(new Dimension(120, 24));
        panelFormulario.add(txtPlazo);

        panelFormulario.add(new JLabel());
        JButton btnSolicitar = new JButton("Solicitar");
        btnSolicitar.setPreferredSize(new Dimension(100, 24));
        btnSolicitar.setFont(new Font("Arial", Font.PLAIN, 12));
        btnSolicitar.setBackground(new Color(0, 123, 255));
        btnSolicitar.setForeground(Color.WHITE);
        panelFormulario.add(btnSolicitar);

        panelPrincipal.add(panelFormulario);
        add(panelPrincipal, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelInferior.setBackground(Color.WHITE);
        panelInferior.setBorder(new EmptyBorder(5, 10, 5, 10));

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setFont(new Font("Arial", Font.PLAIN, 12));
        btnCerrarSesion.setPreferredSize(new Dimension(120, 26));
        btnCerrarSesion.setBackground(new Color(220, 53, 69));
        btnCerrarSesion.setForeground(Color.WHITE);
        panelInferior.add(btnCerrarSesion);

        add(panelInferior, BorderLayout.SOUTH);

        // Acción para solicitar crédito
        btnSolicitar.addActionListener(e -> {
            String monto = txtMonto.getText().trim();
            String plazo = txtPlazo.getText().trim();

            if (monto.isEmpty() || plazo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor llena todos los campos.");
            } else {
                try {
                    double montoDouble = Double.parseDouble(monto);
                    int plazoInt = Integer.parseInt(plazo);

                    Credito credito = new Credito(persona, montoDouble, plazoInt);
                    Cuenta cuenta = controlador.obtenerCuentaPorUsuario(persona.getNombreUsuario());

                    if (cuenta != null) {
                        credito.setNoCuenta(cuenta.getNumeroCuenta());
                        credito.setEstadoActivo(true);
                        String id = "CRED-" + (controlador.getListaCreditos().size() + 1);
                        credito.setIdCredito(id);
                        controlador.agregarCredito(credito);

                        JOptionPane.showMessageDialog(this, "Crédito solicitado con éxito:\nID: " + id);
                        txtMonto.setText("");
                        txtPlazo.setText("");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró una cuenta asociada.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Por favor ingresa valores válidos.");
                }
            }
        });

        btnCerrarSesion.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Sesión cerrada con éxito.");
            Window window = SwingUtilities.windowForComponent(this);
            if (window != null) window.dispose();
            LoginFrame loginFrame = new LoginFrame(controlador);
            loginFrame.setVisible(true);
        });
    }
}

package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Credito;
import modelos.Cuenta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;

public class PanelGestionCreditos extends JPanel {
    private ControladorBanco controlador;
    private JTable tablaCreditos;
    private DefaultTableModel modeloTabla;
    private JLabel lblFondos;

    public PanelGestionCreditos(ControladorBanco controlador) {
        this.controlador = controlador;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton btnAprobar = new JButton("Aprobar/Rechazar");
        JButton btnFondos = new JButton("Consultar Fondos");
        JButton btnReabastecer = new JButton("Reabastecer Fondos");

        btnAprobar.addActionListener(this::gestionarAprobacion);
        btnFondos.addActionListener(e -> actualizarInfoFondos());
        btnReabastecer.addActionListener(this::reabastecerFondos);

        panelBotones.add(btnAprobar);
        panelBotones.add(btnFondos);
        panelBotones.add(btnReabastecer);

        JPanel panelInfo = new JPanel();
        lblFondos = new JLabel();
        actualizarInfoFondos();
        panelInfo.add(lblFondos);

        panelSuperior.add(panelBotones, BorderLayout.WEST);
        panelSuperior.add(panelInfo, BorderLayout.EAST);
        add(panelSuperior, BorderLayout.NORTH);



        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Usuario", "Monto", "Tasa", "Plazo", "Estado"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaCreditos = new JTable(modeloTabla);
        tablaCreditos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tablaCreditos.getColumnModel().getColumn(2).setCellRenderer(new CurrencyRenderer());
        tablaCreditos.getColumnModel().getColumn(3).setCellRenderer(new PercentageRenderer());

        JScrollPane scrollPane = new JScrollPane(tablaCreditos);
        add(scrollPane, BorderLayout.CENTER);


        cargarCreditos();
    }


    private void cargarCreditos() {
        modeloTabla.setRowCount(0);

        for (Credito credito : controlador.getListaCreditos()) {
            Object[] fila = {
                    credito.getId(),
                    credito.getUsuario(),
                    credito.getMonto(),
                    credito.getTasaInteres(),
                    credito.getPlazo() + " meses",
                    credito.isAprobado() ? "Aprobado" : "Pendiente"
            };
            modeloTabla.addRow(fila);
        }
    }

    private void actualizarInfoFondos() {
        double totalFondos = 1000000;
        double prestamos = calcularTotalPrestamosAprobados();
        double disponibles = totalFondos - prestamos;

        lblFondos.setText(String.format(
                "<html><b>Fondos del Banco:</b><br>" +
                        "Total: $%,.2f<br>" +
                        "Prestados: $%,.2f<br>" +
                        "Disponibles: $%,.2f</html>",
                totalFondos, prestamos, disponibles
        ));
    }

    private double calcularTotalPrestamosAprobados() {
        double total = 0;
        for (Credito credito : controlador.getListaCreditos()) {
            if (credito.isAprobado()) {
                total += credito.getMonto();
            }
        }
        return total;
    }

    private void gestionarAprobacion(ActionEvent e) {
        List<Credito> pendientes = new ArrayList<>();
        for (Credito credito : controlador.getListaCreditos()) {
            if (!credito.isAprobado()) {
                pendientes.add(credito);
            }
        }

        if (pendientes.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No hay solicitudes de crédito pendientes",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog();
        dialog.setTitle("Aprobar/Rechazar Créditos");
        dialog.setModal(true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new BorderLayout());

        DefaultTableModel modeloTablaPendientes = new DefaultTableModel(
                new Object[]{"ID", "Usuario", "Cuenta", "Monto", "Tasa", "Plazo", "Estado"}, 0);
        for (Credito credito : pendientes) {
            modeloTablaPendientes.addRow(new Object[]{
                    credito.getId(),
                    credito.getUsuario(),
                    credito.getNoCuenta(),
                    String.format("$%,.2f", credito.getMonto()),
                    String.format("%.2f%%", credito.getTasaInteres()),
                    credito.getPlazo() + " meses",
                    "Pendiente"
            });
        }

        JTable tablaPendientes = new JTable(modeloTablaPendientes);
        tablaPendientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tablaPendientes);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnAprobar = new JButton("Aprobar");
        JButton btnRechazar = new JButton("Rechazar");

        btnAprobar.addActionListener(ev -> {
            int fila = tablaPendientes.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(dialog,
                        "Selecciona un crédito para aprobar",
                        "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String idCredito = modeloTablaPendientes.getValueAt(fila, 0).toString();
            aprobarCredito(idCredito);
            dialog.dispose();
            cargarCreditos();
            actualizarInfoFondos();
        });

        btnRechazar.addActionListener(ev -> {
            int fila = tablaPendientes.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(dialog,
                        "Selecciona un crédito para rechazar",
                        "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String idCredito = modeloTablaPendientes.getValueAt(fila, 0).toString();
            rechazarCredito(idCredito);
            dialog.dispose();
            cargarCreditos();
            actualizarInfoFondos();
        });

        panelBotones.add(btnAprobar);
        panelBotones.add(btnRechazar);
        panel.add(panelBotones, BorderLayout.SOUTH);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void aprobarCredito(String idCredito) {
        try {
            Cuenta tuCuenta = controlador.buscarTuCuentaCredito();

            if (tuCuenta == null) {
                JOptionPane.showMessageDialog(this,
                        "ERROR: No se encontró ninguna tarjeta de crédito en el sistema.\n" +
                                "Por favor crea una tarjeta de crédito primero.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Credito credito = controlador.getListaCreditos().stream()
                    .filter(c -> c.getId().equals(idCredito))
                    .findFirst()
                    .orElse(null);

            if (credito == null) {
                JOptionPane.showMessageDialog(this,
                        "No se encontró el crédito solicitado",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (tuCuenta.getSaldo() < credito.getMonto()) {
                JOptionPane.showMessageDialog(this,
                        String.format("Saldo insuficiente.\nDisponible: $%,.2f\nRequerido: $%,.2f",
                                tuCuenta.getSaldo(), credito.getMonto()),
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            credito.setAprobado(true);
            double saldoAnterior = tuCuenta.getSaldo();
            tuCuenta.setSaldo(saldoAnterior - credito.getMonto());

            tuCuenta.agregarMovimiento(
                    String.format("APROBADO Crédito ID %s - $%,.2f", credito.getId(), credito.getMonto())
            );

            JOptionPane.showMessageDialog(this,
                    String.format("Crédito aprobado exitosamente!\n" +
                                    "Se descontó $%,.2f de tu tarjeta %s\n" +
                                    "Nuevo saldo: $%,.2f",
                            credito.getMonto(),
                            tuCuenta.getNumeroTarjeta(),
                            tuCuenta.getSaldo()),
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);


            cargarCreditos();
            actualizarInfoFondos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error inesperado: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void rechazarCredito(String idCredito) {
        Credito creditoAEliminar = null;
        for (Credito credito : controlador.getListaCreditos()) {
            if (credito.getId().equals(idCredito)) {
                creditoAEliminar = credito;
                break;
            }
        }

        if (creditoAEliminar != null) {
            controlador.getListaCreditos().remove(creditoAEliminar);
            JOptionPane.showMessageDialog(this,
                    "Crédito rechazado exitosamente",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void reabastecerFondos(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Reabastecer Fondos del Banco");
        dialog.setModal(true);
        dialog.setSize(300, 200);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblMonto = new JLabel("Monto a agregar:");
        JTextField txtMonto = new JTextField(10);

        JButton btnAgregar = new JButton("Agregar Fondos");
        btnAgregar.addActionListener(ev -> {
            try {
                double monto = Double.parseDouble(txtMonto.getText());
                if (monto <= 0) {
                    JOptionPane.showMessageDialog(dialog,
                            "El monto debe ser mayor a cero",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }


                JOptionPane.showMessageDialog(dialog,
                        String.format("Se han agregado $%,.2f a los fondos del banco", monto),
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);

                dialog.dispose();
                actualizarInfoFondos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Ingresa un monto válido",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblMonto, gbc);

        gbc.gridx = 1;
        panel.add(txtMonto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(btnAgregar, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }


    class CurrencyRenderer extends DefaultTableCellRenderer {
        @Override
        public void setValue(Object value) {
            if (value instanceof Number) {
                setText(String.format("$%,.2f", value));
            } else {
                super.setValue(value);
            }
        }
    }


    class PercentageRenderer extends DefaultTableCellRenderer {
        @Override
        public void setValue(Object value) {
            if (value instanceof Number) {
                setText(String.format("%.2f%%", value));
            } else {
                super.setValue(value);
            }
        }
    }
}

package vistas.paneles;

import com.fazecast.jSerialComm.SerialPort;
import modelos.Persona;
import controlador.ControladorBanco;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class PanelDepositos extends JPanel {
    private JTextField txtNumeroTarjeta;
    private JTextField txtMonto;
    private JButton btnDepositar;
    private JButton btnCerrarPuerto;
    private ControladorBanco controlador;
    private Persona usuario;
    private SerialPort comPort;
    private Thread lecturaThread;

    private Map<String, String> rfidToCardNumberMap;

    public PanelDepositos(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        rfidToCardNumberMap = new HashMap<>();
        rfidToCardNumberMap.put("7720194", "4111 0012 3456 7890");
        rfidToCardNumberMap.put("9a3a04", "5312 3412 87654 321");
        rfidToCardNumberMap.put("33a44e2d", "6762 0512 3456 7898");

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        iniciarLecturaRFID();

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(new EmptyBorder(20, 40, 20, 40));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Depósito de Fondos");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(new EmptyBorder(10, 0, 20, 0));
        panelPrincipal.add(titulo);

        JPanel panelFormulario = new JPanel(new GridLayout(4, 2, 15, 15));
        panelFormulario.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Datos del Depósito",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));
        panelFormulario.setBackground(new Color(245, 245, 245));

        panelFormulario.add(new JLabel("Número de Tarjeta:"));
        txtNumeroTarjeta = new JTextField();
        txtNumeroTarjeta.setEditable(false);
        panelFormulario.add(txtNumeroTarjeta);

        panelFormulario.add(new JLabel("Monto a Depositar:"));
        txtMonto = new JTextField();
        panelFormulario.add(txtMonto);

        btnDepositar = new JButton("Depositar");
        btnDepositar.setBackground(new Color(40, 167, 69));
        btnDepositar.setForeground(Color.WHITE);
        btnDepositar.setFocusPainted(false);
        btnDepositar.addActionListener(e -> realizarDeposito());
        panelFormulario.add(btnDepositar);

        btnCerrarPuerto = new JButton("Cerrar deposito");
        btnCerrarPuerto.setBackground(new Color(108, 117, 125));
        btnCerrarPuerto.setForeground(Color.WHITE);
        btnCerrarPuerto.setFocusPainted(false);
        btnCerrarPuerto.addActionListener(e -> cerrarPuerto());
        panelFormulario.add(btnCerrarPuerto);

        panelPrincipal.add(panelFormulario);
        add(panelPrincipal, BorderLayout.CENTER);
    }

    private void iniciarLecturaRFID() {
        comPort = SerialPort.getCommPort("COM7");
        comPort.setBaudRate(9600);

        if (comPort.openPort()) {
            System.out.println("Puerto COM7 abierto correctamente.");

            lecturaThread = new Thread(() -> {
                try {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while (!Thread.currentThread().isInterrupted()) {
                        bytesRead = comPort.readBytes(buffer, buffer.length);
                        if (bytesRead > 0) {
                            String received = new String(buffer, 0, bytesRead).trim();
                            if (!received.isEmpty()) {
                                System.out.println("RFID leído: " + received);
                                String numeroTarjeta = rfidToCardNumberMap.get(received);
                                SwingUtilities.invokeLater(() -> {
                                    if (numeroTarjeta != null) {
                                        txtNumeroTarjeta.setText(numeroTarjeta);
                                        realizarDeposito();
                                    } else {
                                        txtNumeroTarjeta.setText("ID no encontrado");
                                    }
                                });
                            }
                        }
                        Thread.sleep(100);
                    }
                } catch (InterruptedException e) {
                    System.out.println("Lectura RFID interrumpida correctamente.");

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    cerrarPuerto();
                }
            });
            lecturaThread.start();
        } else {
            System.out.println("No se pudo abrir el puerto COM7.");
        }
    }

    private void cerrarPuerto() {
        if (lecturaThread != null && lecturaThread.isAlive()) {
            lecturaThread.interrupt();
        }
        if (comPort != null && comPort.isOpen()) {
            comPort.closePort();
            System.out.println("Puerto COM7 cerrado manualmente.");
        }
    }

    private void realizarDeposito() {
        String numeroTarjeta = txtNumeroTarjeta.getText().trim();
        String montoStr = txtMonto.getText().trim();

        if (numeroTarjeta.isEmpty() || montoStr.isEmpty() || numeroTarjeta.equals("ID no encontrado")) {
            JOptionPane.showMessageDialog(this, "Por favor llena todos los campos correctamente.");
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "El monto debe ser mayor a 0.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Monto inválido.");
            return;
        }

        boolean exito = controlador.realizarDeposito(numeroTarjeta, monto);

        if (exito) {
            JOptionPane.showMessageDialog(this, "Depósito realizado con éxito.");
            txtNumeroTarjeta.setText("");
            txtMonto.setText("");
            cerrarPuerto();
        } else {
            JOptionPane.showMessageDialog(this, "Error al realizar el depósito. Verifica el número de tarjeta.");
        }
    }
}

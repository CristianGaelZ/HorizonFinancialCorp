package vistas.paneles;

import com.fazecast.jSerialComm.SerialPort;
import controlador.ControladorBanco;
import modelos.Persona;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class PanelRetiros extends JPanel {
    private JTextField txtNumeroTarjeta;
    private JTextField txtMonto;
    private JLabel lblSaldo;
    private JButton btnRetirar;
    private JButton btnIniciarLectura;
    private JButton btnDetenerLectura;
    private ControladorBanco controlador;
    private Persona usuario;
    private Map<String, String> rfidToCardNumberMap;
    private SerialPort comPort;
    private Thread lecturaThread;

    public PanelRetiros(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        rfidToCardNumberMap = new HashMap<>();
        rfidToCardNumberMap.put("7720194", "4111 0012 3456 7890");
        rfidToCardNumberMap.put("9a3a04", "5312 3412 87654 321");
        rfidToCardNumberMap.put("33a44e2d", "6762 0512 3456 7898");

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(new EmptyBorder(20, 40, 20, 40));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Retiro de Fondos");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(new EmptyBorder(10, 0, 20, 0));
        panelPrincipal.add(titulo);

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 15, 15));
        panelFormulario.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Datos del Retiro",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));
        panelFormulario.setBackground(new Color(245, 245, 245));

        panelFormulario.add(new JLabel("Número de Tarjeta:"));
        txtNumeroTarjeta = new JTextField();
        txtNumeroTarjeta.setEditable(false);
        panelFormulario.add(txtNumeroTarjeta);

        panelFormulario.add(new JLabel("Monto a Retirar:"));
        txtMonto = new JTextField();
        panelFormulario.add(txtMonto);

        panelFormulario.add(new JLabel("Saldo disponible:"));
        lblSaldo = new JLabel("N/A");
        panelFormulario.add(lblSaldo);

        btnIniciarLectura = new JButton("Iniciar retiro");
        btnIniciarLectura.setBackground(new Color(0, 123, 255));
        btnIniciarLectura.setForeground(Color.WHITE);
        btnIniciarLectura.setFocusPainted(false);
        btnIniciarLectura.addActionListener(e -> iniciarLecturaRFID());
        panelFormulario.add(btnIniciarLectura);

        btnDetenerLectura = new JButton("Cerrar retiro");
        btnDetenerLectura.setBackground(new Color(108, 117, 125));
        btnDetenerLectura.setForeground(Color.WHITE);
        btnDetenerLectura.setFocusPainted(false);
        btnDetenerLectura.addActionListener(e -> detenerLecturaRFID());
        panelFormulario.add(btnDetenerLectura);

        btnRetirar = new JButton("Retirar");
        btnRetirar.setBackground(new Color(220, 53, 69));
        btnRetirar.setForeground(Color.WHITE);
        btnRetirar.setFocusPainted(false);
        btnRetirar.addActionListener(e -> realizarRetiro());
        panelFormulario.add(btnRetirar);

        panelPrincipal.add(panelFormulario);
        add(panelPrincipal, BorderLayout.CENTER);
    }

    private void iniciarLecturaRFID() {
        detenerLecturaRFID();

        comPort = SerialPort.getCommPort("COM7");
        comPort.setBaudRate(9600);

        if (comPort.openPort()) {
            System.out.println("Puerto COM7 abierto correctamente.");

            lecturaThread = new Thread(() -> {
                try {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while (!Thread.currentThread().isInterrupted()) {
                        bytesRead = comPort.readBytes(buffer, buffer.length);
                        if (bytesRead > 0) {
                            String received = new String(buffer, 0, bytesRead).trim();
                            if (!received.isEmpty()) {
                                System.out.println("RFID leído: " + received);
                                String numeroTarjeta = rfidToCardNumberMap.get(received);
                                SwingUtilities.invokeLater(() -> {
                                    if (numeroTarjeta != null) {
                                        txtNumeroTarjeta.setText(numeroTarjeta);
                                        Double saldo = controlador.obtenerSaldoPorTarjeta(numeroTarjeta);
                                        if (saldo != null) {
                                            lblSaldo.setText("$" + String.format("%.2f", saldo));
                                        } else {

                                            lblSaldo.setText("Cuenta inactiva o no encontrada");
                                        }
                                    } else {
                                        txtNumeroTarjeta.setText("ID no encontrado");
                                        lblSaldo.setText("N/A");
                                    }
                                });
                            }
                        }
                        Thread.sleep(100);
                    }
                } catch (InterruptedException e) {
                    System.out.println("Lectura RFID interrumpida.");
                    Thread.currentThread().interrupt();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    detenerLecturaRFID();
                }
            });
            lecturaThread.start();
        } else {
            System.out.println("No se pudo abrir el puerto COM7.");
        }
    }

    private void detenerLecturaRFID() {
        if (lecturaThread != null && lecturaThread.isAlive()) {
            lecturaThread.interrupt();
        }
        if (comPort != null && comPort.isOpen()) {
            comPort.closePort();
            System.out.println("Puerto COM7 cerrado.");
        }
    }

    private void realizarRetiro() {
        String numeroTarjeta = txtNumeroTarjeta.getText().trim();
        String montoStr = txtMonto.getText().trim();

        if (numeroTarjeta.isEmpty() || montoStr.isEmpty() || numeroTarjeta.equals("ID no encontrado")) {
            JOptionPane.showMessageDialog(this, "Por favor llena todos los campos correctamente.");
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "El monto debe ser mayor a 0.");
                return;
            }

            if (monto > 10000) {
                JOptionPane.showMessageDialog(this,
                        "No se pueden realizar retiros mayores a $10,000.\nDebe dirigirse a una sucursal bancaria.",
                        "Límite excedido",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            Double saldoDisponible = controlador.obtenerSaldoPorTarjeta(numeroTarjeta);
            if (saldoDisponible == null) {
                JOptionPane.showMessageDialog(this,
                        "No se pudo obtener el saldo de la tarjeta. Verifique que sea válida.",
                        "Error de saldo",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (monto > saldoDisponible) {
                JOptionPane.showMessageDialog(this,
                        "Saldo insuficiente para realizar el retiro.\nSaldo disponible: $" + String.format("%.2f", saldoDisponible),
                        "Saldo insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Monto inválido.");
            return;
        }

        boolean exito = controlador.realizarRetiro(numeroTarjeta, monto);

        if (exito) {
            JOptionPane.showMessageDialog(this, "Retiro realizado con éxito.");
            txtNumeroTarjeta.setText("");
            txtMonto.setText("");
            lblSaldo.setText("N/A");
        } else {
            JOptionPane.showMessageDialog(this, "Error al realizar el retiro. Verifica el número de tarjeta o el saldo disponible.");
        }
    }


}



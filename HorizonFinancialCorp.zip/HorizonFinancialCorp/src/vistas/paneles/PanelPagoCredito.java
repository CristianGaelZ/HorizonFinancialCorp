package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Credito;
import modelos.Cuenta;
import modelos.Persona;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PanelPagoCredito extends JPanel {
    private ControladorBanco controlador;
    private Persona persona;
    private JLabel lblTotalPagar;

    public PanelPagoCredito(ControladorBanco controlador, Persona persona) {
        this.controlador = controlador;
        this.persona = persona;
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(new EmptyBorder(10, 20, 10, 20));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Pago de Crédito");
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(new EmptyBorder(5, 0, 10, 0));
        panelPrincipal.add(titulo);

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 10, 10));
        panelFormulario.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Datos del Pago",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.PLAIN, 12),
                Color.DARK_GRAY
        ));
        panelFormulario.setBackground(new Color(245, 245, 245));

        panelFormulario.add(new JLabel("Total a Pagar:"));
        lblTotalPagar = new JLabel("-");
        panelFormulario.add(lblTotalPagar);

        panelFormulario.add(new JLabel("Tarjeta a Usar:"));
        JTextField txtTarjeta = new JTextField();
        panelFormulario.add(txtTarjeta);

        panelFormulario.add(new JLabel("Monto a Pagar:"));
        JTextField txtMonto = new JTextField();
        panelFormulario.add(txtMonto);

        panelFormulario.add(new JLabel("Fecha de Pago:"));
        JTextField txtFechaPago = new JTextField();
        txtFechaPago.setEditable(false);
        panelFormulario.add(txtFechaPago);

        panelFormulario.add(new JLabel());
        JButton btnPagar = new JButton("Pagar");
        btnPagar.setBackground(new Color(40, 167, 69));
        btnPagar.setForeground(Color.WHITE);
        panelFormulario.add(btnPagar);

        panelPrincipal.add(panelFormulario);
        add(panelPrincipal, BorderLayout.CENTER);

        actualizarTotalAPagar();

        btnPagar.addActionListener(e -> {
            String numeroTarjeta = txtTarjeta.getText().trim();
            String montoStr = txtMonto.getText().trim();

            if (numeroTarjeta.isEmpty() || montoStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor completa todos los campos.");
                return;
            }

            try {
                double monto = Double.parseDouble(montoStr);
                procesarPago(numeroTarjeta, monto);

                txtFechaPago.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                txtTarjeta.setText("");
                txtMonto.setText("");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingresa un monto válido.");
            }
        });
    }

    private void actualizarTotalAPagar() {
        Credito creditoActivo = controlador.obtenerCreditoActivoPorUsuario(persona.getNombreUsuario());
        if (creditoActivo != null && creditoActivo.isAprobado()) {
            lblTotalPagar.setText(String.format("$%,.2f", creditoActivo.calcularTotalPagar()));
        } else {
            lblTotalPagar.setText("No disponible");
        }
    }

    private void procesarPago(String numeroTarjeta, double monto) {
        monto = Math.round(monto * 100.0) / 100.0;

        Cuenta cuenta = controlador.buscarCuentaPorNumeroTarjeta(numeroTarjeta);

        if (cuenta == null) {
            JOptionPane.showMessageDialog(this, "No se encontró la tarjeta especificada.");
            return;
        }

        if ("Crédito".equalsIgnoreCase(cuenta.getTipoCuenta())) {
            JOptionPane.showMessageDialog(this, "No puedes pagar créditos con otra tarjeta de crédito.");
            return;
        }

        double saldoRedondeado = Math.round(cuenta.getSaldo() * 100.0) / 100.0;
        if (saldoRedondeado < monto) {
            JOptionPane.showMessageDialog(this,
                    String.format("Saldo insuficiente en la tarjeta.\nSaldo disponible: $%,.2f", saldoRedondeado));
            return;
        }

        Credito credito = controlador.obtenerCreditoActivoPorUsuario(persona.getNombreUsuario());
        if (credito == null || !credito.isAprobado()) {
            JOptionPane.showMessageDialog(this, "No tienes créditos activos aprobados.");
            return;
        }

        double totalPendiente = Math.round(credito.calcularTotalPagar() * 100.0) / 100.0;
        if (monto > totalPendiente) {
            JOptionPane.showMessageDialog(this,
                    String.format("El monto excede el total a pagar.\nTotal pendiente: $%,.2f", totalPendiente));
            return;
        }

        double nuevoSaldoCuenta = Math.round((cuenta.getSaldo() - monto) * 100.0) / 100.0;
        cuenta.setSaldo(nuevoSaldoCuenta);
        cuenta.agregarMovimiento(String.format("Pago crédito ID %s - $%,.2f", credito.getId(), monto));

        double nuevoSaldoCredito = Math.round((totalPendiente - monto) * 100.0) / 100.0;
        if (nuevoSaldoCredito <= 0.01) {
            credito.setEstadoActivo(false);
            credito.setMonto(0);
            JOptionPane.showMessageDialog(this, "¡Crédito pagado completamente!");
        } else {
            double nuevoMontoBase = Math.round((nuevoSaldoCredito / (1 + (credito.getTasaInteres() / 100 * credito.getPlazo() / 12))) * 100.0) / 100.0;
            credito.setMonto(nuevoMontoBase);
            JOptionPane.showMessageDialog(this,
                    String.format("Pago realizado.\nSaldo restante: $%,.2f", nuevoSaldoCredito));
        }

        actualizarTotalAPagar();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author crist
 */
package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Credito;
import modelos.Persona;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;

public class PanelCreditosCliente extends JPanel {
    private ControladorBanco controlador;
    private Persona usuario;
    private JTable tablaCreditos;
    private DefaultTableModel modeloTabla;
    
    public PanelCreditosCliente(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;
        initComponents();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        JButton btnSolicitar = new JButton("Solicitar Crédito");
        JButton btnPagar = new JButton("Pagar Crédito");
        
        btnSolicitar.addActionListener(this::solicitarCredito);
        btnPagar.addActionListener(this::pagarCredito);
        
        panelBotones.add(btnSolicitar);
        panelBotones.add(btnPagar);
        
        add(panelBotones, BorderLayout.NORTH);
        
        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Monto", "Tasa Interés", "Plazo", "Estado"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tablaCreditos = new JTable(modeloTabla);
        tablaCreditos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(tablaCreditos);
        add(scrollPane, BorderLayout.CENTER);
        
        cargarCreditos();
    }
    
    private void cargarCreditos() {
        modeloTabla.setRowCount(0); // Limpiar tabla
        
        List<Credito> creditosUsuario = obtenerCreditosUsuario();
        
        for(Credito credito : creditosUsuario) {
            Object[] fila = {
                credito.getId(),
                String.format("$%,.2f", credito.getMonto()),
                String.format("%.2f%%", credito.getTasaInteres()),
                credito.getPlazo() + " meses",
                credito.isAprobado() ? "Aprobado" : "Pendiente"
            };
            modeloTabla.addRow(fila);
        }
    }
    
    private List<Credito> obtenerCreditosUsuario() {
        List<Credito> creditosUsuario = new ArrayList<>();
        
        for(Credito credito : controlador.getListaCreditos()) {
            if(credito.getUsuario().equals(usuario.getNombreUsuario())) {
                creditosUsuario.add(credito);
            }
        }
        
        return creditosUsuario;
    }
    
    private void solicitarCredito(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Solicitar Nuevo Crédito");
        dialog.setModal(true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblMonto = new JLabel("Monto del Crédito:");
        JTextField txtMonto = new JTextField(10);
        
        JLabel lblPlazo = new JLabel("Plazo (meses):");
        JSpinner spinnerPlazo = new JSpinner(new SpinnerNumberModel(12, 1, 60, 1));
        
        JLabel lblTasa = new JLabel("Tasa de Interés:");
        JLabel lblTasaValor = new JLabel("5.00%");
        
        JButton btnSolicitar = new JButton("Enviar Solicitud");
        btnSolicitar.addActionListener(ev -> {
            try {
                double monto = Double.parseDouble(txtMonto.getText());
                int plazo = (Integer) spinnerPlazo.getValue();
                double tasaInteres = 5.0;
                
                if(monto > usuario.getLimiteCredito()) {
                    JOptionPane.showMessageDialog(dialog, 
                            "El monto solicitado excede tu límite de crédito de $" + usuario.getLimiteCredito(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                Credito nuevoCredito = new Credito(usuario, monto, plazo);
                controlador.getListaCreditos().add(nuevoCredito);
                
                JOptionPane.showMessageDialog(dialog, 
                        "Solicitud enviada. Espera aprobación del administrador.", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
                dialog.dispose();
                cargarCreditos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, 
                        "Ingresa un monto válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblMonto, gbc);
        
        gbc.gridx = 1;
        panel.add(txtMonto, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblPlazo, gbc);
        
        gbc.gridx = 1;
        panel.add(spinnerPlazo, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblTasa, gbc);
        
        gbc.gridx = 1;
        panel.add(lblTasaValor, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panel.add(btnSolicitar, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void pagarCredito(ActionEvent e) {
        int filaSeleccionada = tablaCreditos.getSelectedRow();
        
        if(filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, 
                    "Selecciona un crédito para pagar", 
                    "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String idCredito = modeloTabla.getValueAt(filaSeleccionada, 0).toString();
        String estado = modeloTabla.getValueAt(filaSeleccionada, 4).toString();
        
        if(!estado.equals("Aprobado")) {
            JOptionPane.showMessageDialog(this, 
                    "Solo puedes pagar créditos aprobados", 
                    "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Estás seguro de que deseas pagar este crédito?", 
                "Confirmar Pago", JOptionPane.YES_NO_OPTION);
        
        if(confirmacion == JOptionPane.YES_OPTION) {
            Credito creditoAPagar = null;
            for(Credito credito : controlador.getListaCreditos()) {
                if(credito.getId().equals(idCredito)) {
                    creditoAPagar = credito;
                    break;
                }
            }
            
            if(creditoAPagar != null) {
                controlador.getListaCreditos().remove(creditoAPagar);
                JOptionPane.showMessageDialog(this, 
                        "Crédito pagado con éxito", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarCreditos(); // Actualizar la tabla
            }
        }
    }
    
    private static class CurrencyRenderer extends DefaultTableCellRenderer {
        public CurrencyRenderer() {
            setHorizontalAlignment(JLabel.RIGHT);
        }
        
        @Override
        public void setValue(Object value) {
            if (value instanceof Number) {
                value = String.format("$%,.2f", ((Number)value).doubleValue());
            }
            super.setValue(value);
        }
    }
}
package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Cuenta;
import modelos.Persona;
import vistas.LoginFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class PanelGestionCuentas extends JPanel {

    private JTable tablaCuentas;
    private DefaultTableModel modeloTabla;
    private ControladorBanco controladorBanco;

    public PanelGestionCuentas(ControladorBanco controladorBanco) {
        this.controladorBanco = controladorBanco;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Crear tabla
        modeloTabla = new DefaultTableModel(new Object[]{
                "ID Persona", "Nombre", "Número de Cuenta", "Tarjeta", "CLABE", "Tipo", "Saldo", "Estado"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaCuentas = new JTable(modeloTabla);
        tablaCuentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tablaCuentas);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton btnControlar = new JButton("Controlar Cuenta");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnSalir = new JButton("Salir");

        btnControlar.addActionListener((ActionEvent e) -> {
            int fila = tablaCuentas.getSelectedRow();
            if (fila != -1) {
                String numeroCuenta = (String) modeloTabla.getValueAt(fila, 2);
                Cuenta cuenta = controladorBanco.obtenerCuentaPorNumero(numeroCuenta);
                if (cuenta != null) {
                    Persona persona = controladorBanco.obtenerPersonaPorId(cuenta.getIdPersona());
                    if (persona != null) {
                        LoginFrame loginFrame = new LoginFrame(controladorBanco);
                        loginFrame.getUsuarioField().setText(persona.getNombreUsuario());
                        loginFrame.getContraseñaField().setText(persona.getPassword());
                        loginFrame.setVisible(true);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una cuenta para controlar.");
            }
        });

        btnEditar.addActionListener((ActionEvent e) -> {
            int fila = tablaCuentas.getSelectedRow();
            if (fila != -1) {
                String numeroCuenta = (String) modeloTabla.getValueAt(fila, 2);
                Cuenta cuenta = controladorBanco.obtenerCuentaPorNumero(numeroCuenta);
                if (cuenta != null) {
                    JPanel panelEdicion = new JPanel(new GridLayout(0, 2));
                    JTextField txtNumeroCuenta = new JTextField(cuenta.getNumeroCuenta());
                    JTextField txtTipoCuenta = new JTextField(cuenta.getTipoCuenta());
                    JTextField txtSaldo = new JTextField(String.valueOf(cuenta.getSaldo()));
                    JComboBox<String> estadoCombo = new JComboBox<>(new String[]{"Activa", "Inactiva"});

                    panelEdicion.add(new JLabel("Número de Cuenta:"));
                    panelEdicion.add(txtNumeroCuenta);
                    panelEdicion.add(new JLabel("Tipo de Cuenta:"));
                    panelEdicion.add(txtTipoCuenta);
                    panelEdicion.add(new JLabel("Saldo:"));
                    panelEdicion.add(txtSaldo);
                    panelEdicion.add(new JLabel("Estado:"));
                    panelEdicion.add(estadoCombo);

                    int opcion = JOptionPane.showConfirmDialog(this, panelEdicion, "Editar Cuenta", JOptionPane.OK_CANCEL_OPTION);
                    if (opcion == JOptionPane.OK_OPTION) {
                        cuenta.setNumeroCuenta(txtNumeroCuenta.getText());
                        cuenta.setTipoCuenta(txtTipoCuenta.getText());
                        cuenta.setSaldo(Double.parseDouble(txtSaldo.getText()));
                        cuenta.setEstadoActivo(estadoCombo.getSelectedIndex() == 0);
                        controladorBanco.actualizarCuenta(cuenta);
                        cargarCuentas();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una cuenta para editar.");
            }
        });

        btnEliminar.addActionListener((ActionEvent e) -> {
            int fila = tablaCuentas.getSelectedRow();
            if (fila != -1) {
                int opcion = JOptionPane.showConfirmDialog(this,
                        "¿Estás seguro de eliminar esta cuenta?", "Confirmar",
                        JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    String numeroCuenta = (String) modeloTabla.getValueAt(fila, 2);
                    controladorBanco.eliminarCuentaPorNumero(numeroCuenta);
                    cargarCuentas();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una cuenta para eliminar.");
            }
        });

        btnSalir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Deseas salir del panel de gestión de cuentas?",
                    "Confirmación",
                    JOptionPane.YES_NO_OPTION
            );
            if (opcion == JOptionPane.YES_OPTION) {
                JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
                topFrame.dispose();
                SwingUtilities.invokeLater(() -> new LoginFrame(controladorBanco).setVisible(true));
            }
        });

        panelBotones.add(btnControlar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnSalir);
        add(panelBotones, BorderLayout.NORTH);

        cargarCuentas();
    }

    private void cargarCuentas() {
        modeloTabla.setRowCount(0);

        List<Cuenta> listaCuentas = controladorBanco.getListaCuentas();
        for (Cuenta cuenta : listaCuentas) {
            Persona persona = controladorBanco.obtenerPersonaPorId(cuenta.getIdPersona());
            String nombre = persona != null ? persona.getNombre() + " " + persona.getApellidoPaterno() : "Desconocido";

            modeloTabla.addRow(new Object[]{
                    cuenta.getIdPersona(),
                    nombre,
                    cuenta.getNumeroCuenta(),
                    cuenta.getNumeroTarjeta(),
                    cuenta.getClabe(),
                    cuenta.getTipoCuenta(),
                    String.format("$%.2f", cuenta.getSaldo()),
                    cuenta.isEstadoActivo() ? "Activa" : "Inactiva"
            });
        }
    }
}

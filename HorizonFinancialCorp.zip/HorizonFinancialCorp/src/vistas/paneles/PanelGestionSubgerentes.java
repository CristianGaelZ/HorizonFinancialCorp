package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Persona;
import vistas.LoginFrame;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PanelGestionSubgerentes extends JPanel {
    private ControladorBanco controlador;
    private JTable tablaSubgerentes;
    private DefaultTableModel modeloTabla;

    public PanelGestionSubgerentes(ControladorBanco controlador) {
        this.controlador = controlador;
        initComponents();
        cargarSubgerentes();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton btnAgregar = new JButton("Agregar Subgerente");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnSalir = new JButton("Salir");

        btnAgregar.addActionListener(this::agregarSubgerente);
        btnEditar.addActionListener(this::editarSubgerente);
        btnEliminar.addActionListener(this::eliminarSubgerente);
        btnSalir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Estás seguro de que deseas cerrar sesión?",
                    "Cerrar Sesión",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (opcion == JOptionPane.YES_OPTION) {
                JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
                topFrame.dispose();

                SwingUtilities.invokeLater(() -> new LoginFrame(controlador).setVisible(true));
            }
        });

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnSalir);

        add(panelBotones, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Usuario", "Email", "Tipo", "RFC", "Fecha Nacimiento", "Contraseña"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaSubgerentes = new JTable(modeloTabla);
        tablaSubgerentes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tablaSubgerentes);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void eliminarSubgerente(ActionEvent e) {
        int filaSeleccionada = tablaSubgerentes.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un subgerente para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar este subgerente?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            String idPersona = modeloTabla.getValueAt(filaSeleccionada, 0).toString();
            Persona subgerente = controlador.buscarPersonaPorId(idPersona);
            if (subgerente != null) {
                subgerente.setEstadoActivo(false);
                controlador.actualizarPersona(subgerente);
                cargarSubgerentes();
                JOptionPane.showMessageDialog(this, "Subgerente eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Subgerente no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editarSubgerente(ActionEvent e) {
        int filaSeleccionada = tablaSubgerentes.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un subgerente para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idPersona = modeloTabla.getValueAt(filaSeleccionada, 0).toString();
        Persona subgerente = controlador.buscarPersonaPorId(idPersona);

        if (subgerente == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el subgerente.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nuevoEmail = JOptionPane.showInputDialog(this, "Editar Email:", subgerente.getEmail());
        if (nuevoEmail == null || nuevoEmail.trim().isEmpty()) return;

        String nuevoPassword = JOptionPane.showInputDialog(this, "Editar Contraseña:", subgerente.getPassword());
        if (nuevoPassword == null || nuevoPassword.trim().isEmpty()) return;

        String nuevaFechaNac = JOptionPane.showInputDialog(this, "Editar Fecha Nacimiento (YYYY-MM-DD):", subgerente.getFechaNacimiento());
        if (nuevaFechaNac == null || nuevaFechaNac.trim().isEmpty()) return;

        if (!validarEmail(nuevoEmail)) {
            JOptionPane.showMessageDialog(this, "Email inválido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        subgerente.setEmail(nuevoEmail);
        subgerente.setPassword(nuevoPassword);
        subgerente.setFechaNacimiento(nuevaFechaNac);
        controlador.actualizarPersona(subgerente);
        cargarSubgerentes();
        JOptionPane.showMessageDialog(this, "Subgerente actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cargarSubgerentes() {
        modeloTabla.setRowCount(0);
        ArrayList<Persona> personas = (ArrayList<Persona>) controlador.getListaPersonas();
        for (Persona persona : personas) {
            if (persona.isEstadoActivo() && "subgerente".equals(persona.getTipo())) {
                String tipoPersona = persona.getRfc().length() == 12 ? "Moral" : "Física";

                Object[] fila = {
                        persona.getIdPersona(),
                        persona.getNombre() + " " + persona.getApellidoPaterno() + " " + persona.getApellidoMaterno(),
                        persona.getNombreUsuario(),
                        persona.getEmail(),
                        tipoPersona,
                        persona.getRfc(),
                        persona.getFechaNacimiento(),
                        persona.getPassword()
                };
                modeloTabla.addRow(fila);
            }
        }
    }

    private void agregarSubgerente(ActionEvent e) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Registrar Nuevo Subgerente");
        dialog.setModal(true);
        dialog.setSize(500, 550);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField(15);
        JLabel lblApellidoPaterno = new JLabel("Apellido Paterno:");
        JTextField txtApellidoPaterno = new JTextField(15);
        JLabel lblApellidoMaterno = new JLabel("Apellido Materno:");
        JTextField txtApellidoMaterno = new JTextField(15);
        JLabel lblUsuario = new JLabel("Nombre de Usuario:");
        JTextField txtUsuario = new JTextField(15);
        JLabel lblRFC = new JLabel("RFC:");
        JTextField txtRFC = new JTextField(15);
        JLabel lblEmail = new JLabel("Email:");
        JTextField txtEmail = new JTextField(15);
        JLabel lblPassword = new JLabel("Contraseña:");
        JPasswordField txtPassword = new JPasswordField(15);
        JLabel lblFechaNacimiento = new JLabel("Fecha de Nacimiento (YYYY-MM-DD):");
        JTextField txtFechaNacimiento = new JTextField(15);
        JLabel lblTipo = new JLabel("Tipo de Persona:");
        ButtonGroup bgTipo = new ButtonGroup();
        JRadioButton rbFisica = new JRadioButton("Física", true);
        JRadioButton rbMoral = new JRadioButton("Moral");
        bgTipo.add(rbFisica);
        bgTipo.add(rbMoral);

        JPanel panelTipo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelTipo.add(rbFisica);
        panelTipo.add(rbMoral);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(ev -> {
            String tipoPersona = rbFisica.isSelected() ? "1" : "2";
            String rfc = txtRFC.getText().trim().toUpperCase();

            if (!validarRFC(rfc, tipoPersona)) {
                JOptionPane.showMessageDialog(dialog, "RFC inválido", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String email = txtEmail.getText().trim();
            if (!validarEmail(email)) {
                JOptionPane.showMessageDialog(dialog, "Email inválido", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String fechaNacimiento = txtFechaNacimiento.getText().trim();
            if (!validarFechaNacimiento(fechaNacimiento)) {
                JOptionPane.showMessageDialog(dialog, "Formato de fecha inválido (Use YYYY-MM-DD)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String idPersona = String.valueOf(System.currentTimeMillis());
            String nombre = txtNombre.getText().trim();
            String apellidoPaterno = txtApellidoPaterno.getText().trim();
            String apellidoMaterno = txtApellidoMaterno.getText().trim();
            String nombreUsuario = txtUsuario.getText().trim();
            String password = new String(txtPassword.getPassword());

            boolean success = controlador.agregarPersona(
                    idPersona,
                    nombre,
                    apellidoPaterno,
                    apellidoMaterno,
                    nombreUsuario,
                    email,
                    rfc,
                    "subgerente",
                    true,
                    password,
                    fechaNacimiento,
                    0
            );

            if (success) {
                dialog.dispose();
                cargarSubgerentes();
                JOptionPane.showMessageDialog(dialog, "Subgerente registrado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(dialog, "El RFC ya está registrado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblNombre, gbc); gbc.gridx = 1; panel.add(txtNombre, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblApellidoPaterno, gbc); gbc.gridx = 1; panel.add(txtApellidoPaterno, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblApellidoMaterno, gbc); gbc.gridx = 1; panel.add(txtApellidoMaterno, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblUsuario, gbc); gbc.gridx = 1; panel.add(txtUsuario, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblRFC, gbc); gbc.gridx = 1; panel.add(txtRFC, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblEmail, gbc); gbc.gridx = 1; panel.add(txtEmail, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblPassword, gbc); gbc.gridx = 1; panel.add(txtPassword, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblFechaNacimiento, gbc); gbc.gridx = 1; panel.add(txtFechaNacimiento, gbc); y++;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lblTipo, gbc); gbc.gridx = 1; panel.add(panelTipo, gbc); y++;
        gbc.gridx = 1; gbc.gridy = y; panel.add(btnGuardar, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private boolean validarRFC(String rfc, String tipoPersona) {
        String regexFisica = "[A-Z&Ñ]{4}\\d{6}[A-Z0-9]{3}";
        String regexMoral = "[A-Z&Ñ]{3}\\d{6}[A-Z0-9]{3}";
        Pattern pattern = Pattern.compile(tipoPersona.equals("1") ? regexFisica : regexMoral);
        Matcher matcher = pattern.matcher(rfc);
        return matcher.matches();
    }

    private boolean validarEmail(String email) {
        String regexEmail = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(regexEmail);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private boolean validarFechaNacimiento(String fecha) {
        return fecha.matches("\\d{4}-\\d{2}-\\d{2}");
    }
}
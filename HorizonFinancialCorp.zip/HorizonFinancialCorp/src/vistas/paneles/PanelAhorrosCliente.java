package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Persona;
import modelos.Cuenta;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;

public class PanelAhorrosCliente extends JPanel {
    private ControladorBanco controlador;
    private Persona usuario;
    private JLabel lblSaldoInversion;
    private Cuenta cuentaInversion;
    private Timer timer;
    private DefaultCategoryDataset dataset;
    private int contadorTiempo = 0;

    public PanelAhorrosCliente(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        cuentaInversion = controlador.obtenerCuentaInversion(usuario);

        if (cuentaInversion != null) {
            lblSaldoInversion = new JLabel("Saldo de inversión: " + cuentaInversion.getSaldo() + " pesos", SwingConstants.CENTER);
            lblSaldoInversion.setFont(new Font("Arial", Font.BOLD, 18));
            lblSaldoInversion.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
            add(lblSaldoInversion, BorderLayout.NORTH);

            dataset = new DefaultCategoryDataset();
            dataset.addValue(cuentaInversion.getSaldo(), "Saldo", "0s");

            JFreeChart chart = ChartFactory.createLineChart(
                    "Crecimiento del Saldo de Inversión",
                    "Tiempo",
                    "Saldo (pesos)",
                    dataset
            );

            ChartPanel chartPanel = new ChartPanel(chart);
            chartPanel.setPreferredSize(new Dimension(800, 400));
            add(chartPanel, BorderLayout.CENTER);

            iniciarTimer();
        } else {
            lblSaldoInversion = new JLabel("No tienes una cuenta de inversión activa.", SwingConstants.CENTER);
            lblSaldoInversion.setFont(new Font("Arial", Font.BOLD, 18));
            add(lblSaldoInversion, BorderLayout.CENTER);
        }
    }

    private void iniciarTimer() {
        timer = new Timer(5000, (ActionEvent e) -> {
            cuentaInversion.setSaldo(cuentaInversion.getSaldo() + 5);
            lblSaldoInversion.setText("Saldo de inversión: " + cuentaInversion.getSaldo() + " pesos");
            contadorTiempo += 5;
            dataset.addValue(cuentaInversion.getSaldo(), "Saldo", contadorTiempo + "s");
        });
        timer.start();
    }
}

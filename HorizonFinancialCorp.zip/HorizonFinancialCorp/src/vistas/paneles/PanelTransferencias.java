package vistas.paneles;

import modelos.Persona;
import controlador.ControladorBanco;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class PanelTransferencias extends JPanel {
    private JTextField txtTarjetaOrigen;
    private JTextField txtTarjetaDestino;
    private JTextField txtMonto;
    private JButton btnTransferir;
    private ControladorBanco controlador;
    private Persona usuario;

    public PanelTransferencias(ControladorBanco controlador, Persona usuario) {
        this.controlador = controlador;
        this.usuario = usuario;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(new EmptyBorder(20, 40, 20, 40));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Transferencia de Fondos");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setBorder(new EmptyBorder(10, 0, 20, 0));
        panelPrincipal.add(titulo);

        JPanel panelFormulario = new JPanel(new GridLayout(4, 2, 15, 15));
        panelFormulario.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Datos de Transferencia",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.DARK_GRAY
        ));
        panelFormulario.setBackground(new Color(245, 245, 245));

        panelFormulario.add(new JLabel("Número de Tarjeta Origen:"));
        txtTarjetaOrigen = new JTextField();
        txtTarjetaOrigen.setEditable(false);

        if (controlador.tieneCuentaDebito(usuario.getIdPersona())) {
            String tarjetaOrigen = controlador.obtenerTarjetaDebitoPorUsuario(usuario.getIdPersona());
            txtTarjetaOrigen.setText(tarjetaOrigen != null ? tarjetaOrigen : "");
        } else {
            txtTarjetaOrigen.setText(""); // No hay cuenta de débito
        }

        panelFormulario.add(txtTarjetaOrigen);

        panelFormulario.add(new JLabel("Número de Tarjeta Destino:"));
        txtTarjetaDestino = new JTextField();
        panelFormulario.add(txtTarjetaDestino);

        panelFormulario.add(new JLabel("Monto a Transferir:"));
        txtMonto = new JTextField();
        panelFormulario.add(txtMonto);

        panelFormulario.add(new JLabel());
        btnTransferir = new JButton("Transferir");
        btnTransferir.setBackground(new Color(0, 123, 255));
        btnTransferir.setForeground(Color.WHITE);
        btnTransferir.setFocusPainted(false);
        panelFormulario.add(btnTransferir);

        panelPrincipal.add(panelFormulario);
        add(panelPrincipal, BorderLayout.CENTER);

        btnTransferir.addActionListener(e -> realizarTransferencia());
    }

    private void realizarTransferencia() {
        String tarjetaOrigen = txtTarjetaOrigen.getText().trim();
        String tarjetaDestino = txtTarjetaDestino.getText().trim();
        String montoStr = txtMonto.getText().trim();

        if (tarjetaOrigen.isEmpty() || tarjetaDestino.isEmpty() || montoStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor llena todos los campos.");
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "El monto debe ser mayor a 0.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Monto inválido.");
            return;
        }

        if (!controlador.tieneCuentaDebito(usuario.getIdPersona())) {
            JOptionPane.showMessageDialog(this, "No tienes una cuenta de débito activa para realizar transferencias.");
            return;
        }

        if (tarjetaOrigen.equals(tarjetaDestino)) {
            JOptionPane.showMessageDialog(this, "No puedes transferir a tu propia tarjeta.");
            return;
        }

        boolean exito = controlador.realizarTransferenciaPorTarjeta(
                tarjetaOrigen, tarjetaDestino, monto, usuario.getIdPersona()
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "Transferencia realizada con éxito.");
            txtTarjetaDestino.setText("");
            txtMonto.setText("");
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al realizar la transferencia. Verifica:\n" +
                            "1. Que no sea a una cuenta de crèdito\n" +
                            "2. Número de tarjeta destino\n" +
                            "3. Saldo suficiente\n" +
                            "4. Que ambas cuentas estén activas\n" +
                            "5. Que tengas una cuenta débito activa");
        }
    }

}
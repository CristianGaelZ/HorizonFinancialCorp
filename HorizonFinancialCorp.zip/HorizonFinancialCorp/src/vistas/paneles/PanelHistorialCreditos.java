package vistas.paneles;

import controlador.ControladorBanco;
import modelos.Credito;
import modelos.Persona;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelHistorialCreditos extends JPanel {
    private ControladorBanco controlador;
    private Persona persona;
    private JTable table;
    private DefaultTableModel tableModel;

    public PanelHistorialCreditos(ControladorBanco controlador, Persona persona) {
        this.controlador = controlador;
        this.persona = persona;
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("Historial de Créditos", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(lblTitulo, BorderLayout.NORTH);

        List<Credito> creditos = controlador.getListaCreditosPorPersona(persona);

        String[] columnNames = {"Monto", "Intereses", "Total con Intereses", "Estado"};

        Object[][] data = new Object[creditos.size()][4];

        int i = 0;
        for (Credito credito : creditos) {
            if (credito.isAprobado()) {
                double monto = credito.getMonto();
                double tasaInteres = credito.getTasaInteres();
                int plazo = credito.getPlazo();
                double interesGenerado = monto * (tasaInteres / 100) * plazo / 12;
                double totalConIntereses = monto + interesGenerado;


                data[i][0] = String.format("$%,.2f", monto);
                data[i][1] = String.format("$%,.2f", interesGenerado);
                data[i][2] = String.format("$%,.2f", totalConIntereses);
                data[i][3] = credito.getEstadoActivo() ? "Activo" : "Saldado";
                i++;
            }
        }


        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void actualizarHistorial() {

        List<Credito> creditos = controlador.getListaCreditosPorPersona(persona);


        int i = 0;
        for (Credito credito : creditos) {
            if (credito.isAprobado()) {

                double monto = credito.getMonto();
                double tasaInteres = credito.getTasaInteres();
                int plazo = credito.getPlazo();
                double interesGenerado = monto * (tasaInteres / 100) * plazo / 12;
                double totalConIntereses = monto + interesGenerado;

                tableModel.setValueAt(String.format("$%,.2f", monto), i, 0);
                tableModel.setValueAt(String.format("$%,.2f", interesGenerado), i, 1);
                tableModel.setValueAt(String.format("$%,.2f", totalConIntereses), i, 2);
                tableModel.setValueAt(credito.getEstadoActivo() ? "Activo" : "Saldado", i, 3);
                i++;
            }
        }
    }
}

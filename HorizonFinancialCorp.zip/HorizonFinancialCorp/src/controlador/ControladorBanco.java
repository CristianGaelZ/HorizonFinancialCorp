package controlador;

import modelos.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ControladorBanco {
    private List<Credito> listaCreditos = new ArrayList<>();
    private List<Persona> listaPersonas = new ArrayList<>();
    private List<Cuenta> listaCuentas = new ArrayList<>();
    private List<Transferencias> listaTransferencias = new ArrayList<>();
    private List<Deposito> listaDepositos = new ArrayList<>();
    private List<Retiro> listaRetiros = new ArrayList<>();

    public List<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public List<Credito> getListaCreditosPorPersona(Persona persona) {
        List<Credito> creditosPorPersona = new ArrayList<>();

        for (Credito credito : listaCreditos) {
            if (credito.getUsuario().equals(persona.getNombreUsuario())) {
                creditosPorPersona.add(credito);
            }
        }

        return creditosPorPersona;
    }

    public void agregarCredito(Credito credito) {
        listaCreditos.add(credito);
    }


    public Persona encontrarUsuario(String user, String pin) {
        for (Persona usuario : listaPersonas) {
            if (pin.equals(usuario.getPassword()) && user.equals(usuario.getNombreUsuario())) {
                return usuario;
            }
        }
        return null;
    }

    public boolean realizarTransferenciaPorTarjeta(String tarjetaOrigen, String tarjetaDestino, double monto, String idPersona) {

        Cuenta cuentaDestino = encontrarCuentaPorTarjeta(tarjetaDestino);
        if (cuentaDestino != null && cuentaDestino.getTipoCuenta().equalsIgnoreCase("Crédito")) {
            return false;
        }


        if (!tieneCuentaDebito(idPersona)) {
            return false;
        }


        Cuenta cuentaOrigen = encontrarCuentaPorTarjeta(tarjetaOrigen);
        if (cuentaOrigen == null || cuentaDestino == null) {
            return false;
        }


        if (!cuentaOrigen.isEstadoActivo() || !cuentaDestino.isEstadoActivo()) {
            return false;
        }


        if (cuentaOrigen.getSaldo() < monto) {
            return false;
        }

        cuentaOrigen.setSaldo(cuentaOrigen.getSaldo() - monto);
        cuentaDestino.setSaldo(cuentaDestino.getSaldo() + monto);


        cuentaOrigen.agregarMovimiento("Transferencia enviada de $" + monto + " a tarjeta " + tarjetaDestino);
        cuentaDestino.agregarMovimiento("Transferencia recibida de $" + monto + " desde tarjeta " + tarjetaOrigen);


        Transferencias transferencia = new Transferencias(
                "T" + (listaTransferencias.size() + 1),
                monto,
                cuentaOrigen.getNumeroCuenta(),
                cuentaDestino.getNumeroCuenta(),
                cuentaOrigen.getClabe(),
                cuentaDestino.getClabe(),
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        );
        listaTransferencias.add(transferencia);

        return true;
    }

    private Cuenta encontrarCuentaPorTarjeta(String tarjeta) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getNumeroTarjeta().equals(tarjeta)) {
                return cuenta;
            }
        }
        return null;
    }

    public Cuenta buscarCuentaPorNumeroTarjeta(String numeroTarjeta) {
        if (numeroTarjeta == null || numeroTarjeta.trim().isEmpty()) {
            return null;
        }

        for (Cuenta cuenta : listaCuentas) {
            if (numeroTarjeta.equals(cuenta.getNumeroTarjeta())) {
                return cuenta;
            }
        }
        return null;
    }

    public List<Transferencias> obtenerHistorialTransferencias(String idPersona) {
        List<Cuenta> cuentasUsuario = obtenerCuentasCliente(idPersona);

        return listaTransferencias.stream()
                .filter(transferencia -> {
                    boolean esCuentaOrigen = cuentasUsuario.stream()
                            .anyMatch(cuenta -> cuenta.getNumeroCuenta().equals(transferencia.getNoCuentaEnvio()));
                    boolean esCuentaDestino = cuentasUsuario.stream()
                            .anyMatch(cuenta -> cuenta.getNumeroCuenta().equals(transferencia.getNoCuentaDestino()));
                    return esCuentaOrigen || esCuentaDestino;
                })
                .collect(Collectors.toList());
    }


    public List<Deposito> obtenerHistorialDepositos(String idPersona) {
        List<Cuenta> cuentasUsuario = obtenerCuentasCliente(idPersona);

        return listaDepositos.stream()
                .filter(deposito -> cuentasUsuario.stream()
                        .anyMatch(cuenta -> cuenta.getNumeroCuenta().equals(deposito.getNoCuentaDestino())))
                .collect(Collectors.toList());
    }


    public List<Retiro> obtenerHistorialRetiros(String idPersona) {
        List<Retiro> historial = new ArrayList<>();

        for (Retiro retiro : listaRetiros) {
            for (Cuenta cuenta : listaCuentas) {
                if (cuenta.getNumeroCuenta().equals(retiro.getNoCuentaOrigen()) &&
                        cuenta.getIdPersona() == idPersona) {
                    historial.add(retiro);
                    break;
                }
            }
        }

        return historial;
    }

    public Persona obtenerPersonaPorId(String idPersona) {
        for (Persona persona : listaPersonas) {
            if (persona.getIdPersona().equals(idPersona)) {
                return persona;
            }
        }
        return null;
    }



    public List<Cuenta> obtenerCuentasCliente(String idPersona) {
        return listaCuentas.stream()
                .filter(cuenta -> cuenta.getIdPersona().equals(idPersona))
                .collect(Collectors.toList());
    }
    public List<Cuenta> obtenerCuentasUsuario(Persona usuario) {
        List<Cuenta> cuentasUsuario = new ArrayList<>();
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getIdPersona().equals(usuario.getIdPersona())) {
                cuentasUsuario.add(cuenta);
            }
        }
        return cuentasUsuario;
    }


    public Cuenta obtenerCuentaInversion(Persona persona) {
        for (Cuenta cuenta : persona.getCuentas()) {
            if (cuenta.getTipoCuenta().equals("Inversión")) {
                return cuenta;
            }
        }
        return null;
    }


    public void agregarCuenta(Cuenta nuevaCuenta) {
        listaCuentas.add(nuevaCuenta);
    }



    public boolean agregarPersona(String idPersona, String nombre, String apellidoPaterno, String apellidoMaterno, String nombreUsuario, String email, String rfc, String tipo,
                                  boolean estadoActivo, String password, String fechaNacimiento, double sueldoAnual) {

        for (Persona persona : listaPersonas) {
            if (persona.getRfc().equalsIgnoreCase(rfc)) {
                return false;
            }
        }

        Persona nuevaPersona = new Persona(idPersona, nombre, apellidoPaterno, apellidoMaterno, nombreUsuario, email, rfc, tipo, estadoActivo, password, fechaNacimiento, sueldoAnual);
        listaPersonas.add(nuevaPersona);

        return true;
    }


    public boolean tieneCuentaCredito(Persona persona) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getIdPersona().equals(persona.getIdPersona()) && cuenta.getTipoCuenta().equalsIgnoreCase("Crédito")) {
                return true;
            }
        }
        return false;
    }

    public boolean tieneCuentaDebito(String idPersona) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getIdPersona().equals(idPersona) && cuenta.getTipoCuenta().equalsIgnoreCase("Débito")) {
                return true;
            }
        }
        return false;
    }



    public Credito obtenerCreditoActivoPorUsuario(String nombreUsuario) {
        for (Credito credito : listaCreditos) {
            if (credito.getUsuario() != null && credito.getUsuario().equals(nombreUsuario) && credito.getEstadoActivo()) {
                return credito;  // Retorna el crédito activo
            }
        }
        return null;
    }


    public Cuenta buscarTuCuentaCredito() {
        for (Cuenta cuenta : listaCuentas) {
            if ("Crédito".equalsIgnoreCase(cuenta.getTipoCuenta())) {

                return cuenta;
            }
        }
        return null;
    }

    public List<Persona> getListaPersonas() {
        return new ArrayList<>(listaPersonas);
    }


    public List<Credito> getListaCreditos() {
        return new ArrayList<>(listaCreditos);
    }


    public Cuenta obtenerCuentaPorUsuario(String nombreUsuario) {
        for (Persona persona : listaPersonas) {
            if (persona.getNombreUsuario().equals(nombreUsuario)) {
                for (Cuenta cuenta : listaCuentas) {
                    if (cuenta.getIdPersona().equals(persona.getIdPersona())) {
                        return cuenta;
                    }
                }
            }
        }
        return null;
    }

    public boolean realizarDeposito(String numeroTarjeta, double monto) {
        for (Cuenta cuenta : listaCuentas) {

            if (cuenta.getNumeroTarjeta().equals(numeroTarjeta) && cuenta.isEstadoActivo()) {

                double saldoActual = cuenta.getSaldo();
                cuenta.setSaldo(saldoActual + monto);


                cuenta.agregarMovimiento("Depósito recibido de $" + monto);


                String idDeposito = "D" + (listaDepositos.size() + 1);
                String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));


                Deposito nuevoDeposito = new Deposito(
                        idDeposito,
                        monto,
                        cuenta.getNumeroCuenta(),
                        cuenta.getNumeroTarjeta(),
                        fechaHora
                );

                listaDepositos.add(nuevoDeposito);

                return true;
            }
        }

        System.out.println("Tarjeta no encontrada o cuenta inactiva.");
        return false;
    }

    public boolean realizarRetiro(String numeroTarjeta, double monto) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroTarjeta) && cuenta.isEstadoActivo()) {

                String tipo = cuenta.getTipoCuenta();
                if (tipo.equalsIgnoreCase("Crédito")) {
                    System.out.println("Las cuentas de crédito no pueden realizar retiros.");
                    return false;
                }

                double saldoActual = cuenta.getSaldo();

                if (monto > saldoActual) {
                    System.out.println("Fondos insuficientes.");
                    return false;
                }

                cuenta.setSaldo(saldoActual - monto);
                cuenta.agregarMovimiento("Retiro realizado por $" + monto);

                String idRetiro = "R" + (listaRetiros.size() + 1);
                String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                Retiro nuevoRetiro = new Retiro(
                        idRetiro,
                        monto,
                        cuenta.getNumeroCuenta(),
                        cuenta.getNumeroTarjeta(),
                        fechaHora
                );

                listaRetiros.add(nuevoRetiro);

                return true;
            }
        }

        System.out.println("Tarjeta no encontrada o cuenta inactiva.");
        return false;
    }

    public String obtenerTarjetaDebitoPorUsuario(String idPersona) {
        for (Cuenta cuenta : listaCuentas) {

            if (cuenta.getIdPersona().equals(idPersona) && cuenta.getTipoCuenta().equalsIgnoreCase("Débito") && cuenta.isEstadoActivo()) {
                return cuenta.getNumeroTarjeta();
            }
        }
        return null;
    }

    public Persona buscarPersonaPorId(String idPersona) {
        for (Persona persona : listaPersonas) {
            if (persona.getIdPersona().equals(idPersona)) {
                return persona;
            }
        }
        return null;
    }

    public void actualizarPersona(Persona personaActualizada) {
        for (int i = 0; i < listaPersonas.size(); i++) {
            if (listaPersonas.get(i).getIdPersona().equals(personaActualizada.getIdPersona())) {
                listaPersonas.set(i, personaActualizada);
                break;
            }
        }
    }
    public Cuenta obtenerCuentaPorNumero(String numeroCuenta) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                return cuenta;
            }
        }
        return null;
    }
    public void eliminarCuentaPorNumero(String numeroCuenta) {
        listaCuentas.removeIf(cuenta -> cuenta.getNumeroCuenta().equals(numeroCuenta));
    }
    public void actualizarCuenta(Cuenta cuenta) {
        if (cuenta != null) {
            for (int i = 0; i < listaCuentas.size(); i++) {
                if (listaCuentas.get(i).getNumeroCuenta().equals(cuenta.getNumeroCuenta())) {
                    listaCuentas.set(i, cuenta); // Actualizamos la cuenta en la lista
                    break;
                }
            }
        } else {
            System.out.println("La cuenta no puede ser null.");
        }
    }

    public Double obtenerSaldoPorTarjeta(String numeroTarjeta) {
        for (Cuenta cuenta : listaCuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroTarjeta) && cuenta.isEstadoActivo()) {
                return cuenta.getSaldo();
            }
        }
        return null;
    }


}
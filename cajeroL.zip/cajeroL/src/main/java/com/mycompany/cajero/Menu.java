package com.mycompany.cajero;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.mycompany.cajero.PinPadDialog;
import com.mycompany.cajero.PinPadNumericoDialog;


public class Menu extends javax.swing.JFrame {
    private String tarjeta;
    private String nombre;
    private String cuenta;
    private String apellido;
    private double dinero;
    private String fechaVencimiento;
    private String cvv;
    private boolean activa;

    public Menu(String tarjeta, String nombre, String cuenta, double dinero, String apellido,
                String fechaVencimiento, String cvv, boolean activa) {
        this.tarjeta = tarjeta;
        this.nombre = nombre;
        this.cuenta = cuenta;
        this.dinero = dinero;
        this.apellido = apellido;
        this.fechaVencimiento = fechaVencimiento;
        this.cvv = cvv;
        this.activa = activa;
        initComponents();
        setLocationRelativeTo(null); // Centrado
        setSize(500, 400);
        actualizarLabel();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("jLabel1");

        jButton1.setText("Retirar");
        jButton1.addActionListener(evt -> jButton1ActionPerformed());

        jButton2.setText("Depositar");
        jButton2.addActionListener(evt -> jButton2ActionPerformed());

        jButton3.setText("Transferir");
        jButton3.addActionListener(evt -> jButton3ActionPerformed());

        jButton4.setText("Salir");
        jButton4.addActionListener(evt -> jButton4ActionPerformed());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(159, 159, 159)
                                .addComponent(jLabel1)
                                .addContainerGap(204, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jButton4)
                                        .addComponent(jButton3)
                                        .addComponent(jButton2)
                                        .addComponent(jButton1))
                                .addGap(53, 53, 53))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(jLabel1)
                                .addGap(42, 42, 42)
                                .addComponent(jButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(jButton3)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)
                                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }

    private void jButton1ActionPerformed() {
        PinPadDialog dialog = new PinPadDialog(this, "Ingrese monto a retirar");
        dialog.setVisible(true);
        double monto = dialog.getCantidadIngresada();

        try {
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "Monto inválido.");
                return;
            }
            if (monto > dinero) {
                JOptionPane.showMessageDialog(this, "Saldo insuficiente.");
                return;
            }
            Connection con = Conexion.conectar();

            PreparedStatement ps = con.prepareStatement("UPDATE cuentas SET saldo = saldo - ? WHERE num_cuenta = ?");
            ps.setDouble(1, monto);
            ps.setString(2, cuenta);
            ps.executeUpdate();

            int idCuenta = -1;
            PreparedStatement psId = con.prepareStatement("SELECT id FROM cuentas WHERE num_cuenta = ?");
            psId.setString(1, cuenta);
            ResultSet rsId = psId.executeQuery();
            if (rsId.next()) {
                idCuenta = rsId.getInt("id");
            }
            rsId.close();
            psId.close();

            double nuevoSaldo = 0;
            PreparedStatement psSaldo = con.prepareStatement("SELECT saldo FROM cuentas WHERE num_cuenta = ?");
            psSaldo.setString(1, cuenta);
            ResultSet rsSaldo = psSaldo.executeQuery();
            if (rsSaldo.next()) {
                nuevoSaldo = rsSaldo.getDouble("saldo");
            }
            rsSaldo.close();
            psSaldo.close();

            if (idCuenta != -1) {
                PreparedStatement psMov = con.prepareStatement("INSERT INTO movimientos (id_cuenta, tipo, monto, saldo_resultante, descripcion) VALUES (?, 'retiro', ?, ?, ?)");
                psMov.setInt(1, idCuenta);
                psMov.setDouble(2, monto);
                psMov.setDouble(3, nuevoSaldo);
                psMov.setString(4, "Retiro en cajero");
                psMov.executeUpdate();
                psMov.close();
            }

            dinero -= monto;
            actualizarLabel();
            JOptionPane.showMessageDialog(this, "Retiro exitoso.");
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }


    private void jButton2ActionPerformed() {
        PinPadDialog dialog = new PinPadDialog(this, "Ingrese monto a depositar");
        dialog.setVisible(true);
        double monto = dialog.getCantidadIngresada();

        try {
            if (monto <= 0) {
                JOptionPane.showMessageDialog(this, "Monto inválido.");
                return;
            }
            Connection con = Conexion.conectar();

            PreparedStatement ps = con.prepareStatement("UPDATE cuentas SET saldo = saldo + ? WHERE num_cuenta = ?");
            ps.setDouble(1, monto);
            ps.setString(2, cuenta);
            ps.executeUpdate();

            int idCuenta = -1;
            PreparedStatement psId = con.prepareStatement("SELECT id FROM cuentas WHERE num_cuenta = ?");
            psId.setString(1, cuenta);
            ResultSet rsId = psId.executeQuery();
            if (rsId.next()) {
                idCuenta = rsId.getInt("id");
            }
            rsId.close();
            psId.close();

            double nuevoSaldo = 0;
            PreparedStatement psSaldo = con.prepareStatement("SELECT saldo FROM cuentas WHERE num_cuenta = ?");
            psSaldo.setString(1, cuenta);
            ResultSet rsSaldo = psSaldo.executeQuery();
            if (rsSaldo.next()) {
                nuevoSaldo = rsSaldo.getDouble("saldo");
            }
            rsSaldo.close();
            psSaldo.close();

            if (idCuenta != -1) {
                PreparedStatement psMov = con.prepareStatement("INSERT INTO movimientos (id_cuenta, tipo, monto, saldo_resultante, descripcion) VALUES (?, 'deposito', ?, ?, ?)");
                psMov.setInt(1, idCuenta);
                psMov.setDouble(2, monto);
                psMov.setDouble(3, nuevoSaldo);
                psMov.setString(4, "Depósito en cajero");
                psMov.executeUpdate();
                psMov.close();
            }

            dinero += monto;
            actualizarLabel();
            JOptionPane.showMessageDialog(this, "Depósito exitoso.");
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }


    private void jButton3ActionPerformed() {
        PinPadNumericoDialog dialog = new PinPadNumericoDialog(this, "Ingrese número de cuenta o tarjeta destino:");
        dialog.setVisible(true);
        String destino = dialog.getTextoIngresado();

        if (destino != null && !destino.isEmpty()) {
            if (destino.equals(this.cuenta) || destino.equals(this.tarjeta)) {
                JOptionPane.showMessageDialog(this, "No puedes transferirte dinero a ti mismo.");
                return;
            }

            boolean existeDestino = false;
            String cuentaDestino = null;

            try {
                Connection conn = Conexion.conectar();

                // Buscar por número de cuenta
                PreparedStatement stmtCuenta = conn.prepareStatement("SELECT num_cuenta FROM cuentas WHERE num_cuenta = ?");
                stmtCuenta.setString(1, destino);
                ResultSet rsCuenta = stmtCuenta.executeQuery();

                if (rsCuenta.next()) {
                    existeDestino = true;
                    cuentaDestino = destino;
                }

                rsCuenta.close();
                stmtCuenta.close();

                if (!existeDestino) {
                    // Buscar por tarjeta y luego obtener el número de cuenta
                    PreparedStatement stmtTarjeta = conn.prepareStatement(
                            "SELECT c.num_cuenta FROM tarjetas t JOIN cuentas c ON t.id_cuenta = c.id WHERE t.numero = ?"
                    );
                    stmtTarjeta.setString(1, destino);
                    ResultSet rsTarjeta = stmtTarjeta.executeQuery();

                    if (rsTarjeta.next()) {
                        existeDestino = true;
                        cuentaDestino = rsTarjeta.getString("num_cuenta");
                    }

                    rsTarjeta.close();
                    stmtTarjeta.close();
                }

                conn.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos:\n" + e.getMessage());
                return;
            }

            if (existeDestino && cuentaDestino != null) {
                PinPadDialog montoDialog = new PinPadDialog(this, "Ingrese cantidad a transferir");
                montoDialog.setVisible(true);
                double cantidad = montoDialog.getCantidadIngresada();

                if (cantidad > 0 && cantidad <= dinero) {
                    try {
                        Connection con = Conexion.conectar();

                        // Obtener ID de cuenta origen
                        int idCuentaOrigen = -1;
                        PreparedStatement psIdOrigen = con.prepareStatement("SELECT id FROM cuentas WHERE num_cuenta = ?");
                        psIdOrigen.setString(1, cuenta);
                        ResultSet rsOrigen = psIdOrigen.executeQuery();
                        if (rsOrigen.next()) {
                            idCuentaOrigen = rsOrigen.getInt("id");
                        }
                        rsOrigen.close();
                        psIdOrigen.close();

                        // Obtener ID de cuenta destino
                        int idCuentaDestino = -1;
                        PreparedStatement psIdDestino = con.prepareStatement("SELECT id FROM cuentas WHERE num_cuenta = ?");
                        psIdDestino.setString(1, cuentaDestino);
                        ResultSet rsDestino = psIdDestino.executeQuery();
                        if (rsDestino.next()) {
                            idCuentaDestino = rsDestino.getInt("id");
                        }
                        rsDestino.close();
                        psIdDestino.close();

                        // Restar al remitente
                        PreparedStatement ps1 = con.prepareStatement("UPDATE cuentas SET saldo = saldo - ? WHERE num_cuenta = ?");
                        ps1.setDouble(1, cantidad);
                        ps1.setString(2, cuenta);
                        ps1.executeUpdate();

                        // Sumar al destinatario
                        PreparedStatement ps2 = con.prepareStatement("UPDATE cuentas SET saldo = saldo + ? WHERE num_cuenta = ?");
                        ps2.setDouble(1, cantidad);
                        ps2.setString(2, cuentaDestino);
                        ps2.executeUpdate();

                        // Obtener saldo actualizado del remitente
                        PreparedStatement saldoRem = con.prepareStatement("SELECT saldo FROM cuentas WHERE num_cuenta = ?");
                        saldoRem.setString(1, cuenta);
                        ResultSet rsSaldoRem = saldoRem.executeQuery();
                        double saldoOrigen = 0.0;
                        if (rsSaldoRem.next()) {
                            saldoOrigen = rsSaldoRem.getDouble("saldo");
                        }
                        rsSaldoRem.close();
                        saldoRem.close();

                        // Registrar movimiento del remitente
                        PreparedStatement psMovRem = con.prepareStatement(
                                "INSERT INTO movimientos (id_cuenta, tipo, monto, saldo_resultante, descripcion, id_cuenta_destino) VALUES (?, 'transferencia', ?, ?, ?, ?)"
                        );
                        psMovRem.setInt(1, idCuentaOrigen);
                        psMovRem.setDouble(2, cantidad);
                        psMovRem.setDouble(3, saldoOrigen);
                        psMovRem.setString(4, "Transferencia enviada");
                        psMovRem.setInt(5, idCuentaDestino);
                        psMovRem.executeUpdate();

                        // Obtener saldo actualizado del destinatario
                        PreparedStatement saldoDest = con.prepareStatement("SELECT saldo FROM cuentas WHERE num_cuenta = ?");
                        saldoDest.setString(1, cuentaDestino);
                        ResultSet rsSaldoDest = saldoDest.executeQuery();
                        double saldoDestino = 0.0;
                        if (rsSaldoDest.next()) {
                            saldoDestino = rsSaldoDest.getDouble("saldo");
                        }
                        rsSaldoDest.close();
                        saldoDest.close();

                        // Registrar movimiento del destinatario
                        PreparedStatement psMovDest = con.prepareStatement(
                                "INSERT INTO movimientos (id_cuenta, tipo, monto, saldo_resultante, descripcion, id_cuenta_destino) VALUES (?, 'transferencia', ?, ?, ?, ?)"
                        );
                        psMovDest.setInt(1, idCuentaDestino);
                        psMovDest.setDouble(2, cantidad);
                        psMovDest.setDouble(3, saldoDestino);
                        psMovDest.setString(4, "Transferencia recibida");
                        psMovDest.setInt(5, idCuentaOrigen);
                        psMovDest.executeUpdate();

                        con.close();

                        dinero -= cantidad;
                        actualizarLabel();
                        JOptionPane.showMessageDialog(this,
                                "Transferencia exitosa de $" + cantidad + " a " + destino + "\nNuevo saldo: $" + dinero);
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error al procesar la transferencia:\n" + e.getMessage());
                    }

                } else if (cantidad > 0) {
                    JOptionPane.showMessageDialog(this, "Fondos insuficientes.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "El número ingresado no existe como cuenta ni como tarjeta.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Debe ingresar un número válido.");
        }
    }



    private void jButton4ActionPerformed() {
        this.dispose();
        new inicio().setVisible(true);
    }

    private void actualizarLabel() {
        jLabel1.setText("<html>Tarjeta: " + tarjeta +
                "<br>Nombre: " + nombre + " " + apellido +
                "<br>Cuenta: " + cuenta +
                "<br>Saldo: $" + dinero +
                "<br>Vence: " + fechaVencimiento +
                "<br>CVV: " + cvv +
                "<br>Activa: " + (activa ? "Sí" : "No"));
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new Menu("numeroTarjeta", "nombreCliente", "numeroCuenta", 1000.0, "Apellido", "2025-12-31", "123", true).setVisible(true);
        });
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
}

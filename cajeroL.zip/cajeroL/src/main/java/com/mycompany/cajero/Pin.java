package com.mycompany.cajero;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import com.mycompany.cajero.PinPadNumericoDialog;

public class Pin extends javax.swing.JFrame {
    private String tarjeta;

    public Pin(String tarjeta) {
        this.tarjeta = tarjeta;
        initComponents();
        solicitarPin();
    }

    public Pin() {
        this.tarjeta = "";
        initComponents();
        solicitarPin();
    }

    private void solicitarPin() {
        PinPadNumericoDialog pinPad = new PinPadNumericoDialog(this, "Ingrese su PIN");
        pinPad.setVisible(true);
        String resultado = pinPad.getTextoIngresado();

        if (resultado != null) {
            verificarPin(resultado); // ✅ Agregado para procesar el PIN
        } else {
            JOptionPane.showMessageDialog(this, "Operación cancelada.");
            dispose(); // o System.exit(0); si se ocupa salir completamente
        }
    }

    private void verificarPin(String pin) {
        try {
            Connection con = Conexion.conectar();
            PreparedStatement ps = con.prepareStatement(
                    "SELECT t.numero, t.fecha_vencimiento, t.cvv, t.activa, u.nombre, c.num_cuenta, c.saldo " +
                            "FROM tarjetas t " +
                            "JOIN cuentas c ON t.id_cuenta = c.id " +
                            "JOIN usuarios u ON c.id_usuario = u.id " +
                            "WHERE t.numero = ? AND t.pin = ?"
            );
            ps.setString(1, tarjeta);
            ps.setString(2, pin);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String numeroTarjeta = rs.getString("numero");
                String fechaVencimiento = rs.getString("fecha_vencimiento");
                String cvv = rs.getString("cvv");
                boolean activa = rs.getBoolean("activa");
                String nombre = rs.getString("nombre");
                String numeroCuenta = rs.getString("num_cuenta");
                double saldo = rs.getDouble("saldo");

                Menu menu = new Menu(numeroTarjeta, nombre, numeroCuenta, saldo, "", fechaVencimiento, cvv, activa);
                menu.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "PIN o tarjeta incorrectos.");
                solicitarPin(); // Reintentar
            }

            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos:\n" + e.getMessage());
        }
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(1, 1);  // Oculta la ventana
        setLocationRelativeTo(null);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Pin("numeroTarjeta").setVisible(true));
    }
}

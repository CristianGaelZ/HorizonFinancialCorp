package com.mycompany.cajero;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PinPadDialog extends JDialog {
    private JTextField texto;
    private double cantidadIngresada = 0;

    public PinPadDialog(Frame parent, String titulo) {
        super(parent, titulo, true);
        setLayout(new BorderLayout());

        texto = new JTextField();
        texto.setFont(new Font("SansSerif", Font.PLAIN, 24));
        texto.setHorizontalAlignment(JTextField.RIGHT);
        add(texto, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            String num = String.valueOf(i);
            JButton boton = new JButton(num);
            boton.setFont(new Font("SansSerif", Font.BOLD, 20));
            boton.addActionListener(e -> texto.setText(texto.getText() + num));
            panelBotones.add(boton);
        }

        // Botón de punto decimal
        JButton punto = new JButton(".");
        punto.setFont(new Font("SansSerif", Font.BOLD, 20));
        punto.addActionListener(e -> {
            if (!texto.getText().contains(".")) {
                texto.setText(texto.getText() + ".");
            }
        });

        // Botón de cero
        JButton cero = new JButton("0");
        cero.setFont(new Font("SansSerif", Font.BOLD, 20));
        cero.addActionListener(e -> texto.setText(texto.getText() + "0"));

        // Botón de borrar
        JButton borrar = new JButton("⌫");
        borrar.setFont(new Font("SansSerif", Font.BOLD, 20));
        borrar.addActionListener(e -> {
            String actual = texto.getText();
            if (!actual.isEmpty()) {
                texto.setText(actual.substring(0, actual.length() - 1));
            }
        });

        panelBotones.add(punto);
        panelBotones.add(cero);
        panelBotones.add(borrar);

        add(panelBotones, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new FlowLayout());
        JButton aceptar = new JButton("Aceptar");
        aceptar.setFont(new Font("SansSerif", Font.BOLD, 18));
        aceptar.addActionListener(e -> {
            try {
                cantidadIngresada = Double.parseDouble(texto.getText());
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un número válido.");
            }
        });

        JButton cancelar = new JButton("Cancelar");
        cancelar.setFont(new Font("SansSerif", Font.BOLD, 18));
        cancelar.addActionListener(e -> {
            cantidadIngresada = 0;
            dispose();
        });

        panelInferior.add(aceptar);
        panelInferior.add(cancelar);

        add(panelInferior, BorderLayout.SOUTH);

        setSize(300, 400);
        setLocationRelativeTo(parent);
        SwingUtilities.invokeLater(() -> texto.requestFocusInWindow());

    }

    public double getCantidadIngresada() {
        return cantidadIngresada;
    }
}

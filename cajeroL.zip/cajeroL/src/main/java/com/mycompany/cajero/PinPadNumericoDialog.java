package com.mycompany.cajero;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PinPadNumericoDialog extends JDialog {
    private JTextField display;
    private String textoIngresado = null;

    public PinPadNumericoDialog(JFrame parent, String titulo) {
        super(parent, titulo, true);
        setLayout(new BorderLayout());

        display = new JTextField();
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(display, BorderLayout.NORTH);

        // 🔽 Esto habilita escritura con teclado físico
        display.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (Character.isDigit(c)) {
                    display.setText(display.getText() + c);
                } else if (c == '\b' && !display.getText().isEmpty()) {
                    display.setText(display.getText().substring(0, display.getText().length() - 1));
                } else if (c == 127 || c == KeyEvent.VK_DELETE) {
                    display.setText("");
                }
            }
        });

        JPanel pad = new JPanel(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            agregarBoton(pad, String.valueOf(i));
        }
        agregarBoton(pad, "←");
        agregarBoton(pad, "0");
        agregarBoton(pad, "C");
        add(pad, BorderLayout.CENTER);

        JButton aceptar = new JButton("Aceptar");
        aceptar.addActionListener(e -> {
            if (!display.getText().isEmpty()) {
                textoIngresado = display.getText();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Debe ingresar un número válido.");
            }
        });
        add(aceptar, BorderLayout.SOUTH);

        setSize(300, 400);
        setLocationRelativeTo(parent);

        SwingUtilities.invokeLater(() -> display.requestFocusInWindow());
    }

    private void agregarBoton(JPanel panel, String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("SansSerif", Font.BOLD, 20));
        boton.addActionListener(e -> {
            if (texto.equals("C")) {
                display.setText("");
            } else if (texto.equals("←")) {
                String actual = display.getText();
                if (!actual.isEmpty())
                    display.setText(actual.substring(0, actual.length() - 1));
            } else {
                display.setText(display.getText() + texto);
            }
        });
        panel.add(boton);
    }

    public String getTextoIngresado() {
        return textoIngresado;
    }
}

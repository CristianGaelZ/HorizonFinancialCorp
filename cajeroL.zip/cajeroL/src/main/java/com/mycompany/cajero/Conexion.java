package com.mycompany.cajero;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection conectar() {
        try {
            return DriverManager.getConnection("jdbc:mysql://192.168.43.236:3306/banco", "root", "123456");
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}